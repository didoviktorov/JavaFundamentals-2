import java.util.Scanner;

public class task_05_PascalTriangle {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int rows = Integer.parseInt(scanner.nextLine());
        long[] previousRow;
        long[] currentRow = {1};
        System.out.println(printArray(currentRow));
        previousRow = currentRow;
        for (int i = 2; i <= rows; i++) {
            currentRow = new long[i];
            currentRow[0] = 1;
            currentRow[i - 1] = 1;
            for (int j = 0; j <= i - 3; j++) {
                currentRow[j + 1] = previousRow[j] + previousRow[j + 1];
            }
            System.out.println(printArray(currentRow));
            previousRow = currentRow;
            
        }
    }
    
    private static String printArray (long[] arr) {
        String result = "";
        for (int i = 0; i < arr.length; i++) {
            if (i == arr.length - 1) {
                result += arr[i];
            } else {
                result += arr[i] + " ";
            }

        }

        return result;
    }
}
