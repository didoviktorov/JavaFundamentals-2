import java.util.Arrays;
import java.util.Scanner;

public class task_01_SortArray {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int num = Integer.parseInt(scanner.nextLine());
        String[] arr = new String[num];
        for (int i = 0; i < num; i++) {
            arr[i] = scanner.nextLine();
        }

        Arrays.sort(arr);
        for (String s : arr) {
            System.out.println(s);
        }
    }
}
