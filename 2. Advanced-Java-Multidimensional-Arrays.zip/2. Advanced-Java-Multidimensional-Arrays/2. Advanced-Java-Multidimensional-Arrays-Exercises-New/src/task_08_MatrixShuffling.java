import java.util.Scanner;

public class task_08_MatrixShuffling {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String[] dimensions = scanner.nextLine().split("\\s+");
        int rows = Integer.parseInt(dimensions[0]);
        int cols = Integer.parseInt(dimensions[1]);
        String[][] matrix = new String[rows][cols];
        for (int row = 0; row < matrix.length; row++) {
            matrix[row] = scanner.nextLine().split("\\s+");
        }

        String command = scanner.nextLine();
        while (!command.equals("END")) {
            String[] arguments = command.split("\\s+");
            if (!validCords(arguments, rows, cols)) {
                System.out.println("Invalid input!");
            } else {
                int firstRow = Integer.parseInt(arguments[1]);
                int firstCol = Integer.parseInt(arguments[2]);
                int secondRow = Integer.parseInt(arguments[3]);
                int secondCol = Integer.parseInt(arguments[4]);

                String a = matrix[firstRow][firstCol];
                String b = matrix[secondRow][secondCol];
                //String temp = b;

                matrix[secondRow][secondCol] = a;
                matrix[firstRow][firstCol] = b;
                for (int row = 0; row < matrix.length; row++) {
                    System.out.println(String.join(" ", matrix[row]));

                }
            }

            command = scanner.nextLine();
        }
    }

    private static boolean validCords (String[] cmd, int rows, int cols) {
        boolean valid = true;
        if (!cmd[0].equals("swap") || cmd.length != 5) {
            valid = false;
        } else {
            int row1 = Integer.parseInt(cmd[1]);
            int col1 = Integer.parseInt(cmd[2]);
            int row2 = Integer.parseInt(cmd[3]);
            int col2 = Integer.parseInt(cmd[4]);
            if (row1 < 0 || row1 >= rows) {
                valid = false;
            } else if (row2 < 0 || row2 >= rows) {
                valid = false;
            } else if (col1 < 0 || col1 >= cols) {
                valid = false;
            } else if (col2 < 0 || col2 >= cols) {
                valid = false;
            }
        }

        return valid;
    }
}
