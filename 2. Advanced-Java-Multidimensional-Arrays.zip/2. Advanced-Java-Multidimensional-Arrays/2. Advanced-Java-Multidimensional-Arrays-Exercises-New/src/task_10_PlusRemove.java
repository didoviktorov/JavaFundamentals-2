import java.util.ArrayList;
import java.util.Scanner;

public class task_10_PlusRemove {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        ArrayList<char[]> lines = new ArrayList<>();
        ArrayList<char[]> result = new ArrayList<>();

        String line = scanner.nextLine();
        while(!line.equals("END")) {
            lines.add(line.toLowerCase().toCharArray());
            result.add(line.toCharArray());

            line = scanner.nextLine();
        }

        for (int row = 0; row < lines.size(); row++) {
            for (int col = 0; col < lines.get(row).length; col++) {
                findPlusShape(lines, row, col, result);
            }

        }

        for (char[] chars : result) {
            for (char aChar : chars) {
                System.out.print(aChar);
            }
            System.out.println();
        }
    }

    private static void findPlusShape (ArrayList<char[]> lines, int row, int col, ArrayList<char[]> result) {
        char symbol = lines.get(row)[col];
        if (row - 1 >= 0
                && row + 1 < lines.size()
                && col - 1 >= 0
                && col + 1 < lines.get(row).length
                && lines.get(row - 1).length > col
                && lines.get(row + 1).length > col
                && lines.get(row - 1)[col] == symbol
                && lines.get(row + 1)[col] == symbol
                && lines.get(row)[col - 1] == symbol
                && lines.get(row)[col + 1] == symbol
                ) {
            result.get(row)[col] = '\0';
            result.get(row - 1)[col] = '\0';
            result.get(row + 1)[col] = '\0';
            result.get(row)[col + 1] = '\0';
            result.get(row)[col - 1] = '\0';
        }
    }
}


