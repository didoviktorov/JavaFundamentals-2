import java.util.Scanner;

public class task_01_FillTheMatrix {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String[] dimensions = scanner.nextLine().split(", ");
        int rowsCols = Integer.parseInt(dimensions[0]);
        String pattern = dimensions[1];
        
        int[][] matrix = new int[rowsCols][rowsCols];

        switch (pattern) {
            case "A":
                matrix = fillPatternA(rowsCols);
                break;
            case "B":
                matrix = fillPatternB(rowsCols);
                break;
        }

        for (int row = 0; row < rowsCols; row++) {
            String result = "";
            for (int col = 0; col < rowsCols; col++) {
                if (col != rowsCols - 1) {
                    result += matrix[row][col] + " ";
                } else {
                    result += matrix[row][col];
                }
            }
            System.out.println(result);
        }
    }

    public static int[][] fillPatternA (int num) {
        int[][] matrix = new int[num][num];
        int numberToFill = 1;
        for (int row = 0; row < num; row++) {
            for (int col = 0; col < num; col++) {
                matrix[col][row] = numberToFill;
                numberToFill++;
            }
        }
        return matrix;
    }

    public static int[][] fillPatternB (int num) {
        int[][] matrix = new int[num][num];
        int numberToFill = 1;
        for (int row = 0; row < num; row++) {
            if (row % 2 == 0) {
                for (int col = 0; col < num; col++) {
                    matrix[col][row] = numberToFill;
                    numberToFill++;
                }
            } else {
                for (int col = num - 1; col >= 0; col--) {
                    matrix[col][row] = numberToFill;
                    numberToFill++;
                }
            }

        }
        return matrix;
    }
}
