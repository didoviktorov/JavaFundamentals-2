import java.util.Scanner;

public class task_05_MaximalSum {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String[] dimensions = scanner.nextLine().split(" ");
        int rows = Integer.parseInt(dimensions[0]);
        int cols = Integer.parseInt(dimensions[1]);

        String[][] matrix = new String[rows][cols];
        for (int row = 0; row < rows; row++) {
            matrix[row] = scanner.nextLine().split("\\s+");
        }

        long sum = Long.MIN_VALUE;
        String[][] maxMatrix = new String[3][3];
        for (int row = 0; row < rows - 2; row++) {
            for (int col = 0; col < cols - 2; col++) {
                long currentSum = 0;

                long a = Long.parseLong(matrix[row][col]);
                long b = Long.parseLong(matrix[row][col + 1]);
                long c = Long.parseLong(matrix[row][col + 2]);
                long d = Long.parseLong(matrix[row + 1][col]);
                long f = Long.parseLong(matrix[row + 1][col + 1]);
                long e = Long.parseLong(matrix[row + 1][col + 2]);
                long g = Long.parseLong(matrix[row + 2][col]);
                long i = Long.parseLong(matrix[row + 2][col + 1]);
                long j = Long.parseLong(matrix[row + 2][col + 2]);

                currentSum += (a + b + c + d + f + e + g + i + j);
                if (currentSum > sum) {
                    sum = currentSum;
                    maxMatrix[0][0] = a + "";
                    maxMatrix[0][1] = b + "";
                    maxMatrix[0][2] = c + "";
                    maxMatrix[1][0] = d + "";
                    maxMatrix[1][1] = f + "";
                    maxMatrix[1][2] = e + "";
                    maxMatrix[2][0] = g + "";
                    maxMatrix[2][1] = i + "";
                    maxMatrix[2][2] = j + "";
                }
            }
        }

        System.out.println("Sum = " + sum);
        for (int i = 0; i < 3; i++) {
            System.out.println(String.join(" ", maxMatrix[i]));
        }
    }
}