import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.function.Predicate;

public class task_04_FindEvenOrOdds {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String[] range = scanner.nextLine().trim().split("\\s+");
        String condition = scanner.nextLine();

        int start = Integer.parseInt(range[0]);
        int end = Integer.parseInt(range[1]);
        getNumbers(start, end, condition, ifCondition(condition));

    }

    public static void getNumbers(int start, int end, String cond, Predicate<Integer> condition) {
        StringBuilder sb = new StringBuilder();
        for (int i = start; i <= end; i++) {
             if (condition.test(i)){
                 sb.append(i).append(" ");
             }
        }
        System.out.println(sb.toString().trim());
    }

    public static Predicate<Integer> ifCondition(String condition) {
        switch (condition) {
            case "odd":
                return x -> x % 2 != 0;
            default:
                return x -> x % 2 == 0;
        }
    }
}
