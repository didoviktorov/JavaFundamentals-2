import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Set;
import java.util.function.BiPredicate;
import java.util.stream.Collectors;

public class task_10_ListOfPredicates {
    public static void main(String[] args) throws IOException {

        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        int bound = Integer.parseInt(br.readLine());

        Set<Integer> numbers = Arrays.stream(br.readLine().split("\\s+"))
                .map(str -> Integer.valueOf(str))
                .collect(Collectors.toSet());

        BiPredicate<Set<Integer>, Integer> test = (x, y ) -> {
            boolean t = false;
            for (Integer n : x) {
                if (y % n == 0) {
                    t = true;
                } else {
                    t = false;
                    break;
                }
            }
            return t;
        };

        List<String> derivatives = new ArrayList<>();
        for (int i = 1; i <= bound; i++) {
            if (test.test(numbers, i)) {
                derivatives.add(i + "");
            }

        }
        System.out.println(String.join(" ", derivatives));
    }
}
