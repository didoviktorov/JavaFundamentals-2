import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;
import java.util.function.BiPredicate;

public class task_13_Inferno_3 {
    public static void main(String[] args) throws IOException {

        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

        String[] nums = br.readLine().trim().split("\\s+");
        Long[] numbers = new Long[nums.length];
        for (int i = 0; i < nums.length; i++) {
            numbers[i] = Long.parseLong(nums[i]);
        }

        boolean[] marks = new boolean[numbers.length];
        String[] line = br.readLine().trim().split(";");
        List<String> commands = new ArrayList<>();
        while (!line[0].equals("Forge")) {
            BiPredicate<Long, Integer> ifCondition = test(line, numbers);
            String command = line[0];

            switch (command) {
                case "Exclude":
                    for (int i = 0; i < numbers.length; i++) {
                        if (ifCondition.test(numbers[i], i)) {
                            marks[i] = true;
                        }
                    }
                    break;
                case "Reverse":
                    for (int i = 0; i < numbers.length; i++) {
                        if (ifCondition.test(numbers[i], i)) {
                            marks[i] = false;
                        }
                    }
                    break;
            }

            commands.add(command + ";" + line[1] + ";" + line[2]);
            line = br.readLine().trim().split(";");
        }

        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < numbers.length; i++) {
            if (!marks[i]) {
                sb.append(numbers[i] + " ");
            }

        }

        System.out.println(sb.toString().trim());
    }

    private static BiPredicate<Long, Integer> test (String[] cmd, Long[] numbers) {
        String command = cmd[1];
        Long sum = Long.parseLong(cmd[2]);
        switch (command) {
            case "Sum Left":
                return (x, y) -> {
                    long currSum = 0;
                    if (y != 0) {
                        currSum += (numbers[y] + numbers[y - 1]);
                    } else {
                        currSum += numbers[y];
                    }
                    return currSum == sum;
                };
            case "Sum Right":
                return (x, y) -> {
                    long currSum = 0;
                    if (y != numbers.length - 1) {
                        currSum += (numbers[y] + numbers[y + 1]);
                    } else {
                        currSum += numbers[y];
                    }
                    return currSum == sum;
                };
            case "Sum Left Right":
                return (x, y) -> {
                    long currSum = 0;
                    if (y != numbers.length - 1 && y != 0) {
                        currSum += (numbers[y] + numbers[y + 1] + numbers[y - 1]);
                    } else if (numbers.length > 1) {
                        if (y == 0){
                            currSum += (numbers[y] + numbers[y + 1]);
                        } else if (y == numbers.length - 1){
                            currSum += (numbers[y] + numbers[y - 1]);
                        }
                    } else {
                        currSum += numbers[y];
                    }

                    return currSum == sum;
                };
            default:
                return null;

        }
    }
}
