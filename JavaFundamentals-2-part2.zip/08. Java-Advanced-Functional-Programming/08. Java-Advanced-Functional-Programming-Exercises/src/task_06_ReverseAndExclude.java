import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Arrays;
import java.util.function.BiPredicate;

public class task_06_ReverseAndExclude {
    public static void main(String[] args) throws IOException {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        int[] numbers = Arrays.stream(br.readLine().split("\\s+")).mapToInt(Integer::parseInt).toArray();

        BiPredicate<Integer, Integer> test = (x, y) -> {
            return x % y != 0;
        };

        int number = Integer.parseInt(br.readLine());
        for (int i = numbers.length - 1; i >= 0; i--) {
            if (test.test(numbers[i], number)){
                System.out.print(numbers[i] + " ");
            }
        }
        System.out.println();
    }
}
