import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.function.BiPredicate;
import java.util.function.Predicate;
import java.util.stream.Collectors;

public class task_11_PredicateParty {
    public static void main(String[] args) throws IOException {

        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        List<String> persons = Arrays.stream(br.readLine().split("\\s+"))
                .map(s -> s)
                .collect(Collectors.toList());

        String[] line = br.readLine().split("\\s+");
        while (!line[0].equals("Party!")) {
            Predicate<String> ifCondition = test(line);
            switch (line[0]) {
                case "Remove":
                    persons.removeIf(ifCondition);
                    break;
                case "Double":
                    List<String> temp = new ArrayList<>();
                    persons.forEach( x -> {
                        if(ifCondition.test(x)) {
                            temp.add(x);
                        }
                        temp.add(x);
                    });
                    persons = temp;
                    break;
            }

            line = br.readLine().split("\\s+");
        }

        if (persons.size() > 0) {
            System.out.println(String.join(", ", persons) + " are going to the party!");
        } else {
            System.out.println("Nobody is going to the party!");
        }
    }

    private static Predicate<String> test (String[] cmd) {
        String command = cmd[1];
        switch (command) {
            case "StartsWith":
                return x -> x.indexOf(cmd[2]) != -1;
            case "EndsWith":
                return x -> x.indexOf(cmd[2]) != -1;
            case "Length":
                return x -> x.length() == Integer.parseInt(cmd[2]);
            default:
                return null;

        }
    }

}
