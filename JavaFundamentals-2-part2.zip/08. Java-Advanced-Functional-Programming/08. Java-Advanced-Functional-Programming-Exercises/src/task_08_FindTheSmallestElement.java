import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Arrays;
import java.util.function.BiPredicate;

public class task_08_FindTheSmallestElement {
    public static void main(String[] args) throws IOException {

        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        int[] numbers = Arrays.stream(br.readLine().trim().split("\\s+")).mapToInt(Integer::parseInt).toArray();

        int min = Integer.MAX_VALUE;
        int index = 0;
        BiPredicate<Integer, Integer> test = (x, y) -> x <= y;
        for (int i = 0; i < numbers.length; i++) {
            if (test.test(numbers[i], min)) {
                index = i;
                min = numbers[i];
            }
        }

        System.out.println(index);
    }
}


