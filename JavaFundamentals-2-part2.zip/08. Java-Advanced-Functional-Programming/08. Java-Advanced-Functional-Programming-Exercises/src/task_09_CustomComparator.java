import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Arrays;
import java.util.Comparator;

public class task_09_CustomComparator {
    public static void main(String[] args) throws IOException {

        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        String[] nums =br.readLine().trim().split("\\s+");
        Integer[] numbers = new Integer[nums.length];
        for (int i = 0; i < nums.length; i++) {
            numbers[i] = Integer.parseInt(nums[i]);

        }

        Comparator<Integer> customComparator = (x, y) -> {
            if (Math.abs(x) % 2 == 0 && Math.abs(y) % 2 != 0)
                return -1;
            else if (Math.abs(x) % 2 != 0 && Math.abs(y) % 2 == 0)
                return 1;
            else
                return x.compareTo(y);
        };


        Arrays.sort(numbers, customComparator);

        StringBuilder sb = new StringBuilder();
        for (Integer number : numbers) {
            sb.append(number + " ");
        }
        System.out.println(sb.toString().trim());
    }
}