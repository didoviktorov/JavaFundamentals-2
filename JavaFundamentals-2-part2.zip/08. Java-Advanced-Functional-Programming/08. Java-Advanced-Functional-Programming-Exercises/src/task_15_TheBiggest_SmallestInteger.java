import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Arrays;
import java.util.function.BiFunction;

public class task_15_TheBiggest_SmallestInteger {
    public static void main(String[] args) throws IOException {

        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

        int[] numbers = Arrays.stream(br.readLine().split("\\s+")).mapToInt(Integer::parseInt).toArray();
        String command = br.readLine();

        BiFunction<int[], String, Integer> biggest = (x, y) -> {
            int max = Integer.MIN_VALUE;
                switch (y) {
                    case "maxEven":
                        for (int i : x) {
                            if (i % 2 == 0 && i > max) {
                                max = i;
                            }
                        }
                    return max;
                    case "maxOdd":
                        for (int i : x) {
                            if (i % 2 != 0 && i > max) {
                                max = i;
                            }
                        }
                        return max;
                    default:
                        return null;

                }
        };

        BiFunction<int[], String, Integer> smallest = (x, y) -> {
            int min = Integer.MAX_VALUE;
            switch (y) {
                case "minEven":
                    for (int i : x) {
                        if (i % 2 == 0 && i < min) {
                            min = i;
                        }
                    }
                    return min;
                case "minOdd":
                    for (int i : x) {
                        if (i % 2 != 0 && i < min) {
                            min = i;
                        }
                    }
                    return min;
                default:
                    return null;

            }
        };

        BiFunction<BiFunction<int[], String, Integer>, BiFunction<int[], String, Integer>, Integer> result =
            (funcA, funcB) -> {
                int r;
                if (command.contains("max")) {
                    r = biggest.apply(numbers, command);
                } else {
                    r = smallest.apply(numbers, command);
                }

                return r;
            };

        int res = result.apply(biggest, smallest);
        if (res != Integer.MAX_VALUE && res != Integer.MIN_VALUE) {
            System.out.println(res);
        }

        br.close();
    }
}
