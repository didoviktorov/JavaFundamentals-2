import java.util.Scanner;
import java.util.function.Consumer;

public class task_01_ConsumerPrint {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String[] words = scanner.nextLine().split("\\s+");

        Consumer<String> print = msg -> System.out.println(msg);
        for (String word : words) {
            print.accept(word);
        }
    }
}
