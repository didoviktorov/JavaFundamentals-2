import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.function.Predicate;

public class task_12_ThePartyReservationFilterModule {
    public static void main(String[] args) throws IOException {

        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        String[] names = br.readLine().trim().split("\\s+");

        LinkedHashMap<String, Boolean> persons = new LinkedHashMap<>();
        for (String name : names) {
            persons.put(name, true);
        }

        String[] line = br.readLine().trim().split(";");
        while (!line[0].equals("Print")) {
            Predicate<String> ifCondition = test(line);
            switch (line[0]){
                case "Add filter":
                    for (Map.Entry<String, Boolean> p : persons.entrySet()) {
                        if (ifCondition.test(p.getKey())){
                            persons.put(p.getKey(), false);
                        }
                    }
                    break;
                case "Remove filter":
                    for (Map.Entry<String, Boolean> p : persons.entrySet()) {
                        if (ifCondition.test(p.getKey())){
                            persons.put(p.getKey(), true);
                        }
                    }
                    break;
            }

            line = br.readLine().trim().split(";");
        }

        StringBuilder sb = new StringBuilder();
        for (String name : names) {
            if (persons.get(name)) {
                sb.append(name + " ");
            }
        }

        System.out.println(sb.toString().trim());
    }

    private static Predicate<String> test (String[] cmd) {
        String command = cmd[1];
        switch (command) {
            case "Starts with":
                return x -> x.trim().startsWith(cmd[2].trim());
            case "Ends with":
                return x -> x.trim().endsWith(cmd[2].trim());
            case "Length":
                return x -> x.trim().length() == Integer.parseInt(cmd[2].trim());
            case "Contains":
                return x -> x.trim().contains(cmd[2].trim());
            default:
                return null;

        }
    }
}
