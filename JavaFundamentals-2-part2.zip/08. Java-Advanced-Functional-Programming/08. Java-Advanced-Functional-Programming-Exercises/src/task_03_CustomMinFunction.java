import java.util.Arrays;
import java.util.Scanner;
import java.util.function.Function;

public class task_03_CustomMinFunction {
    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);

        String[] nums = scanner.nextLine().split("\\s+");
        Integer[] numbers = new Integer[nums.length];
        for (int i = 0; i < numbers.length; i++) {
             numbers[i] = Integer.parseInt(nums[i]);
        }

        Function<Integer[], Integer> min = getMin(numbers);
        System.out.println(min.apply(numbers));
    }

    private static Function<Integer[], Integer> getMin (Integer[] nums) {
        Arrays.sort(nums);
        return  x -> x[0];
    }
}
