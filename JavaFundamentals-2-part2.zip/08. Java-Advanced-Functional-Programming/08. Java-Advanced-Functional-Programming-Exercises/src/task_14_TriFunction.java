import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.function.BiFunction;

public class task_14_TriFunction {
    public static void main(String[] args) throws IOException {

        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

        int sum = Integer.parseInt(br.readLine());
        ArrayList<String> persons = new ArrayList<>(Arrays.asList(br.readLine().split("\\s+")));

        BiFunction<String, Integer, Boolean> sumIsValid =
                (name, s) -> {
                    int currSum = 0;
                    for (char c : name.toCharArray()) {
                        currSum += c;
                    }

                    return currSum >= s;
                };

        TriFunction<Integer, BiFunction<String, Integer, Boolean>, ArrayList<String>, String> triFunction =
                (a, b, c) -> {
                    for (String name : c) {
                        if (b.apply(name, a)) {
                            return name;
                        }
                    }
                    return null;
                };

        String resultName = triFunction.apply(sum, sumIsValid, persons);
        if (resultName != null) {
            System.out.println(resultName);
        }

        br.close();
    }

    interface TriFunction<A, B, C, R> {
        R apply(A integer, B biFunction, C arrayList);
    }
}
