import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Arrays;
import java.util.function.BiFunction;
import java.util.function.Consumer;

public class task_05_AppliedArithmetic {
    public static void main(String[] args) throws IOException {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        int[] numbers = Arrays.stream(br.readLine().split("\\s+")).mapToInt(Integer::parseInt).toArray();

        BiFunction<String, Integer, Integer> test = (x, y) -> {
            switch (x) {
                case "add":
                    return y + 1;
                case "multiply":
                    return y * 2;
                case "subtract":
                    return y - 1;
                default:
                    return null;
            }
        };

        Consumer<Integer> print = x-> System.out.print(x + " ");

        String line = br.readLine();
        while (!line.equals("end")) {
            if (!line.equals("print")) {
                for (int i = 0; i < numbers.length; i++) {
                    numbers[i] = test.apply(line, numbers[i]);
                }
            } else {
                for (int number : numbers) {
                    print.accept(number);
                }
                System.out.println();
            }
            line = br.readLine();
        }

    }

}