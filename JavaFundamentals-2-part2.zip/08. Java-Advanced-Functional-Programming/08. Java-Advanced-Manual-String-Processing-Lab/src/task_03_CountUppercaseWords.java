import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;
import java.util.function.Predicate;

public class task_03_CountUppercaseWords {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        String[] input = scanner.nextLine().split(" ");

        Predicate<String> startUppercase = str -> Character.isUpperCase(str.charAt(0));
        List<String> uppercaseWords = new ArrayList<>();
        for (String word : input) {
            if (startUppercase.test(word)) {
                uppercaseWords.add(word);
            }
        }
        System.out.println(uppercaseWords.size());
        System.out.println(String.join("\n", uppercaseWords));
    }
}
