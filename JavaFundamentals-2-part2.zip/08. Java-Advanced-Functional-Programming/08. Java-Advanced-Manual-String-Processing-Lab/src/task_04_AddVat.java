import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.function.UnaryOperator;

public class task_04_AddVat {
    public static void main(String[] args) throws IOException {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

        String[] input = br.readLine().split(", ");
        UnaryOperator<String> addVat = x -> String.format("%1.2f", Double.parseDouble(x) * 1.2);
        System.out.println("Prices with VAT:");
        StringBuilder sb = new StringBuilder();
        for (String price : input) {
            sb.append(addVat.apply(price).replace(".", ",")).append("\n");
        }
        System.out.println(sb);
    }
}