import java.io.*;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.function.Consumer;
import java.util.function.Predicate;

public class task_05_FilterByAge {
    public static void main(String[] args) throws IOException {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

        int lines = Integer.parseInt(br.readLine());
        LinkedHashMap<String, Integer> persons = new LinkedHashMap<>();
        for (int i = 0; i < lines; i++) {
            String[] params = br.readLine().split(", ");
            String name = params[0].trim();
            int age = Integer.parseInt(params[1].trim());
            persons.put(name, age);
        }

        String condition = br.readLine();
        int age = Integer.parseInt(br.readLine());
        String style = br.readLine();


        Predicate<Integer> tester = condition(condition, age);
        Consumer<Map.Entry<String, Integer>> printer = printStyle(style);
        for (Map.Entry<String, Integer> p : persons.entrySet()) {
            if (tester.test(persons.get(p.getKey()))) {
                printer.accept(p);
            }
        }
    }

    private static void printPersons(
            HashMap<String, Integer> persons,
            Predicate<Integer> tester,
            Consumer<Map.Entry<String, Integer>> printer) {

    }

    private static Consumer<Map.Entry<String, Integer>> printStyle (String style) {
        switch (style) {
            case "age":
                return p -> System.out.printf("%d\n", p.getValue());
            case "name":
                return p -> System.out.printf("%s\n", p.getKey());
            default:
                return p -> System.out.printf("%s - %d\n", p.getKey(), p.getValue());
        }
    }

    private static Predicate<Integer> condition (String condition, Integer age) {
        switch (condition) {
            case "younger":
                return x -> x < age;
            default:
                return x -> x >= age;
        }
    }
}
