import java.util.*;

public class task_01_SortOddNumbers {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        List<String> nums = Arrays.asList(scanner.nextLine().split(", "));
        List<Integer> numbers = new ArrayList<>();
        for (String number : nums) {
            numbers.add(Integer.parseInt(number));
        }

        numbers.removeIf(a -> a % 2 != 0);
        StringBuilder sb = new StringBuilder();
        for (Integer number : numbers) {
            sb.append(number + ", ");
        }

        if (sb.length() > 0)
            sb.delete(sb.length() - 2, sb.length());

        System.out.println(sb);

        sb = new StringBuilder();
        numbers.sort((a, b) -> a.compareTo(b));
        for (Integer number : numbers) {
            sb.append(number + ", ");
        }

        if (sb.length() > 0)
            sb.delete(sb.length() - 2, sb.length());

        System.out.println(sb);

    }
}
