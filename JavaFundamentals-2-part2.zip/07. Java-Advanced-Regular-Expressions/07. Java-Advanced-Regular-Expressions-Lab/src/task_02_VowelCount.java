import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class task_02_VowelCount {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        String text = scanner.nextLine();

        Pattern pattern = Pattern.compile("[aAeEiIoOuUyY]");
        Matcher matcher = pattern.matcher(text);

        int vowels = 0;
        while (matcher.find()) {
            vowels++;
        }

        System.out.println("Vowels: " + vowels);
    }
}
