import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class task_03_NonDigitCount {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        String text = scanner.nextLine();

        Pattern pattern = Pattern.compile("[\\D]");
        Matcher matcher = pattern.matcher(text);

        int nonDigits = 0;
        while (matcher.find()) {
            nonDigits++;
        }

        System.out.println("Non-digits: " + nonDigits);
    }
}
