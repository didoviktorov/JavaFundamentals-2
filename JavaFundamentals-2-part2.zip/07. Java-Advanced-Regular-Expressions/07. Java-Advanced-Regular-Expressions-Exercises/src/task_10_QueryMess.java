import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class task_10_QueryMess {
    public static void main(String[] args) throws IOException {

        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

        Pattern regex = Pattern.compile("(.+)=(.+)");

        String line = br.readLine();
        while (!line.equals("END")) {
            String[] pairs = line.split("&");
            LinkedHashMap<String, List<String>> info = new LinkedHashMap<>();
            for (int i = 0; i < pairs.length; i++) {
                Matcher matcher = regex.matcher(pairs[i]);
                if(matcher.find()){
                    String key = matcher.group(1).replaceAll("\\+", " ")
                            .replaceAll("%20", " ").replaceAll("\\s+", " ").trim();

                    String value = matcher.group(2).replaceAll("\\+", " ")
                            .replaceAll("%20", " ").replaceAll("\\s+", " ").trim();

                    if(key.contains("?")){
                        key = key.substring(key.indexOf("?") + 1, key.length());
                    }

                    if(value.contains("?")){
                        value = value.substring(value.indexOf("?") + 1, value.length());
                    }

                    if(!info.containsKey(key)){
                        info.put(key, new ArrayList<>());
                    }

                    info.get(key).add(value);
                }
            }

            for (Map.Entry<String, List<String>> entry : info.entrySet()) {
                System.out.printf("%s=%s", entry.getKey(), entry.getValue().toString());
            }

            System.out.println();

            line = br.readLine();
        }
    }
}
