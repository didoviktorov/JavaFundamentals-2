import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class task_06_SentenceExtractor {
    public static void main(String[] args) throws IOException {

        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        String word = br.readLine();

        String text = br.readLine();

        Pattern sentenceRegex = Pattern.compile("([^.!?]+(?=[.!?])[.!?])");
        Pattern wordRegex = Pattern.compile(".*?\\b" + word + "\\b.*?");

        Matcher matcher = sentenceRegex.matcher(text);
        Matcher wordMatcher;
        while(matcher.find()){
            String sentence = matcher.group().trim();
            wordMatcher = wordRegex.matcher(sentence);

            if(wordMatcher.find()){
                System.out.println(sentence);
            }
        }

    }
}
