import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class task_07_PhoneNumbers {
    public static void main(String[] args) throws IOException {

        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

        Pattern pairs = Pattern.compile("([A-Z][a-zA-z]*?)([^a-zA-Z\\+]*?)([\\+]?[0-9][().\\/\\- 0-9]*[0-9])");

        String line = br.readLine();
        StringBuilder result = new StringBuilder();
        result.append("<ol>");
        StringBuilder text = new StringBuilder();

        while (!line.equals("END")) {
            text.append(line);
            line = br.readLine();
        }

        boolean matches = false;
        Matcher matcher = pairs.matcher(text.toString());
        while (matcher.find()) {
            matches = true;
            String name = matcher.group(1);
            String phone = matcher.group(3);
            phone = phone.replaceAll("[().\\/\\- ]", "");
            result.append("<li><b>").append(name).append(":</b> ");
            result.append(phone).append("</li>");
        }
        result.append("</ol>");
        if (matches) {
            System.out.println(result);
        } else {
            System.out.println("<p>No matches!</p>");
        }
    }
}
