import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class task_11_ExtractHyperlinks {
    public static void main(String[] args) throws IOException {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

        String line  = br.readLine();
        StringBuilder text = new StringBuilder();
        while (!line.equals("END")) {
            text.append(line);
            line = br.readLine();
        }

        String regex = "<a\\s+(?:[^>]+\\s+)?href\\s*=\\s*(?:'([^']*)'|\\\"([^\\\"]*)\\\"|([^\\s>]+))[^>]*>";
        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(text.toString());

        while (matcher.find()) {
            for (int i = 1; i <= matcher.groupCount(); i++) {
                if (matcher.group(i) != null) {
                    System.out.println(matcher.group(i));
                }
            }
        }
    }
}
