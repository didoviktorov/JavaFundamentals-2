import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class task_08_SumOfAllValues {
    public static void main(String[] args) throws IOException {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

        Pattern keys = Pattern.compile("^([a-zA-Z_]+)[0-9](.*)[0-9]([a-zA-Z_]+)$");

        String keyString = br.readLine();
        Matcher matcher = keys.matcher(keyString);
        if (!matcher.find()) {
            System.out.println("<p>A key is missing</p>");
        } else {
            String startKey = matcher.group(1);
            String endKey = matcher.group(3);

            Pattern textValues = Pattern.compile(startKey + "([\\-]*?[0-9]*[\\.]*?[0-9]+)" + endKey);
            String text = br.readLine();
            Matcher values = textValues.matcher(text);
            double sum = 0;
            while (values.find()) {
                sum += Double.parseDouble(values.group(1));
            }

            if (sum == 0) {
                System.out.println("<p>The total value is: <em>nothing</em></p>");
            } else {
                if (sum % 1 != 0) {
                    System.out.println(String.format("<p>The total value is: <em>%.2f</em></p>", sum));
                } else {
                    System.out.println(String.format("<p>The total value is: <em>%d</em></p>", (int)sum));
                }

            }
        }
    }
}
