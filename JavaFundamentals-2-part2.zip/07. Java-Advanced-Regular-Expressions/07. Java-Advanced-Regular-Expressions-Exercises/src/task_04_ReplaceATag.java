import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class task_04_ReplaceATag {
    public static void main(String[] args) throws IOException {

        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        StringBuilder text = new StringBuilder();
        String line = br.readLine();
        while (!line.equals("END")) {
            text.append(line).append("\r\n");
            line = br.readLine();
        }

        Pattern pattern = Pattern.compile("<a\\s+(href=[^>]+)>([^<]+)<\\/a>");
        Matcher matcher = pattern.matcher(text.toString().trim());
        while (matcher.find()) {
            int matcherStart = matcher.start();
            int matcherEnd = matcher.end();
            String replacement = "[URL " + matcher.group(1) + "]" + matcher.group(2) + "[/URL]";
            text.replace(matcherStart, matcherEnd, replacement);
            matcher = pattern.matcher(text);
        }

        System.out.println(text);
    }
}
