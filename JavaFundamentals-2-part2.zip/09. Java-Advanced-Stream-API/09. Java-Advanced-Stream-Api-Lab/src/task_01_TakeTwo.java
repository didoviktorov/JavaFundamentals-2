import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class task_01_TakeTwo {
    public static void main(String[] args) throws IOException {

        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

        int[] input = Arrays.stream(br.readLine().split("\\s+")).mapToInt(Integer::parseInt).toArray();
        List<Integer> numberList = new ArrayList<>(Arrays.stream(input).boxed().collect(Collectors.toList()));

        numberList.stream().filter(x -> x >= 10 && x <= 20).distinct().limit(2)
                .forEach(n -> System.out.print(n + " "));
    }
}
