import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

public class task_03_FirstName {
    public static void main(String[] args) throws IOException {

        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

        List<String> strings = Arrays.asList(br.readLine().split("\\s+"));

        HashSet<Character> letters = Arrays.stream(br.readLine().split("\\s+"))
                .map(x -> x.toLowerCase().charAt(0)).collect(Collectors.toCollection(HashSet::new));

        Optional<String> first = strings.stream().filter(s -> letters.contains(s.toLowerCase().charAt(0)))
                .sorted().findFirst();

        if (first.isPresent()) {
            System.out.println(first.get());
        } else {
            System.out.println("No match");
        }
    }
}
