import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.*;
import java.util.function.Consumer;
import java.util.function.Predicate;

public class task_07_MapDistricts {
    public static void main(String[] args) throws IOException {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

        List<String> elements = Arrays.asList(br.readLine().split("\\s+"));
        LinkedHashMap<String, List<Integer>> cities = new LinkedHashMap<>();

        for (String element : elements) {
            String[] params = element.split(":");
            String city = params[0];
            int population = Integer.valueOf(params[1]);

            cities.putIfAbsent(city, new ArrayList<>());
            cities.get(city).add(population);
        }

        int bound = Integer.valueOf(br.readLine());

        // First way to do it
//        cities.entrySet().stream()
//                .filter(getFilteredByPopulation(bound))
//                .sorted(sortDescendingByPopulation())
//                .forEach(print());

        // Second way to do it
        cities.entrySet().stream()
                .filter(c -> c.getValue().stream().mapToInt(Integer::valueOf).sum() > bound)
                .sorted((kv1, kv2) -> Integer.compare(
                        kv2.getValue().stream().mapToInt(Integer::valueOf).sum(),
                        kv1.getValue().stream().mapToInt(Integer::valueOf).sum())
                )
                .forEach(d -> {
                    System.out.printf("%s: ", d.getKey());
                    d.getValue().stream()
                            .sorted((a,b) -> Integer.compare(b, a))
                            .limit(5)
                            .forEach(p -> System.out.print(p + " "));
                    System.out.println();
                });

    }

    private static Predicate<Map.Entry<String, List<Integer>>> getFilteredByPopulation(int bound) {
        return kv -> kv.getValue().stream()
                .mapToInt(Integer::intValue)
                .sum() >= bound;
    }

    private static Comparator<Map.Entry<String, List<Integer>>> sortDescendingByPopulation() {
        return (kv1, kv2) ->
                Integer.compare(
                        kv2.getValue().stream().mapToInt(Integer::intValue).sum(),
                        kv1.getValue().stream().mapToInt(Integer::intValue).sum()
                );
    }

    private static Consumer<Map.Entry<String, List<Integer>>> print () {
        return kv -> {
            System.out.printf("%s: ", kv.getKey());
            kv.getValue().stream()
                    .sorted((s1, s2) -> Integer.compare(s2, s1))
                    .limit(5)
                    .forEach(d -> System.out.print(d + " "));
            System.out.println();
        };
    }
}
