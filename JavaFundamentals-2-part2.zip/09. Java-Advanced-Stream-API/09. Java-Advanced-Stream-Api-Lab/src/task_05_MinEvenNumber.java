import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.*;
import java.util.stream.Collectors;

public class task_05_MinEvenNumber {
    public static void main(String[] args) throws IOException {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

        List<String> elements = Arrays.asList(br.readLine().split("\\s+"));

        List<Double> numbers = elements
                .stream()
                .filter(x-> !x.isEmpty())
                .map(Double::parseDouble)
                .filter(x -> x % 2 == 0)
                .sorted(Double::compareTo)
                .collect(Collectors.toCollection(ArrayList::new));

        Optional<Double> result = numbers.stream().findFirst();
        if (result.isPresent()) {
            System.out.printf("%.2f", result.get());
        } else {
            System.out.println("No match");
        }
    }
}
