import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

public class task_06_FindAndSumIntegers {
    public static void main(String[] args) throws IOException {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

        List<String> elements = Arrays.asList(br.readLine().split("\\s+"));


        Optional<Integer> result = elements.stream()
                .filter(x -> isNumber(x))
                .map(Integer::parseInt)
                .reduce((x, y) -> x + y);

        if (result.isPresent()) {
            System.out.println(result.get());
        } else {
            System.out.println("No match");
        }

    }

    private static boolean isNumber(String x) {
        if (x.isEmpty()) {
            return false;
        }

        if (x.charAt(0) == '-' || x.charAt(0) == '+' || Character.isDigit(x.charAt(0))) {
            for (int i = 1; i < x.length(); i++) {
                if (!Character.isDigit(x.charAt(i))) {
                    return false;
                }
            }
        }  else {
            return false;
        }
        return true;
    }
}
