import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.TreeMap;

public class task_11_OfficeStuff {
    public static void main(String[] args) throws IOException {

        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

        int lines = Integer.valueOf(br.readLine());
        TreeMap<String, LinkedHashMap<String, Long>> companies = new TreeMap<>();

        for (int i = 0; i < lines; i++) {
            String line = br.readLine();
            String test = line.substring(1, line.length());
            String[] params = line.substring(1, line.length() - 1).split(" - ");
            String companyName = params[0];
            long currentAmount = Long.valueOf(params[1]);
            String product = params[2];

            if (!companies.containsKey(companyName)) {
                companies.put(companyName, new LinkedHashMap<>());
            }
            if (!companies.get(companyName).containsKey(product)) {
                companies.get(companyName).put(product, 0l);
            }

            companies.get(companyName).put(product, companies.get(companyName).get(product) + currentAmount);

        }

        companies.entrySet().stream()
            .forEach(c -> {
                System.out.print(c.getKey() + ": ");
                List<String> products = new ArrayList<>();
                c.getValue().entrySet().stream()
                    .forEach(p -> {
                        products.add(p.getKey() + "-" + p.getValue());
                    });
                System.out.print(String.join(", ", products));
                System.out.println();
            });
    }
}
