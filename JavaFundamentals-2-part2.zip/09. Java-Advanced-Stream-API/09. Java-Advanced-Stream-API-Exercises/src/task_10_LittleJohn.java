import java.io.*;
import java.util.regex.*;

public class task_10_LittleJohn {
    public static void main(String[] args) throws IOException {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

        String regex = "(>>>----->>)|(>>----->)|(>----->)";
        Pattern pattern = Pattern.compile(regex);

        int large = 0;
        int medium = 0;
        int small = 0;
        for (int i = 0; i < 4; i++) {
            String line = br.readLine();
            Matcher matcher = pattern.matcher(line);
            while (matcher.find()) {
                if (matcher.group().equals(matcher.group(1))) {
                    large++;
                } else if (matcher.group().equals(matcher.group(2))) {
                    medium++;
                } else {
                    small++;
                }
            }
        }

        String number = "" + small + medium + large;
        String binary = Integer.toBinaryString(Integer.valueOf(number));

        String reversed = "";
        for (int i = binary.length() - 1; i >= 0; i--) {
            reversed += binary.charAt(i);
        }

        binary += reversed;
        int result = Integer.parseInt(binary, 2);
        System.out.println(result);
    }
}
