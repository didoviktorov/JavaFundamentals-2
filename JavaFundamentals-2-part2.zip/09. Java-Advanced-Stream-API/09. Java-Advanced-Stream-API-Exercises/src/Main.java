import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.function.Predicate;
import java.util.stream.Collectors;

public class Main {

    private final static String path = "/src/";

    public static void main(String[] args) {

        String projectPath = System.getProperty("user.dir");
        Path studentsDataPath = Paths.get(projectPath + path + "StudentData.txt");
        List<String> data = new ArrayList<>();

        try {
            data = Files.readAllLines(studentsDataPath);
        } catch (IOException e) {
            e.printStackTrace();
        }
        List<Student> students = new ArrayList<>();
        for (int i = 1; i < data.size(); i++) {
            String[] tokens = data.get(i).split("\\s+");
            String facNum = tokens[0];
            String firstName = tokens[1];
            String lastName = tokens[2];
            String email = tokens[3];
            Integer age = Integer.valueOf(tokens[4]);
            Integer group = Integer.valueOf(tokens[5]);
            String phone = tokens[10];

            Student student = new Student(
                facNum, firstName, lastName, email, age, group, phone);

            for (int gradeIndex = 6; gradeIndex <= 9; gradeIndex++) {
                Integer grade = Integer.valueOf(tokens[gradeIndex]);
                student.getGrades().add(grade);
            }

            students.add(student);
        }

        // Task_01_Students by Group
//        students.stream()
//            .filter(s -> s.getGroup() == 2)
//            .sorted((s1, s2) -> s1.getFirstName().compareTo(s2.getFirstName()))
//            .forEach(s -> System.out.println(s.getFirstName() + " " + s.getLastName()));

        // Task_02_Students by First and Last Name
//        students.stream()
//            .filter(s -> s.getFirstName().compareTo(s.getLastName()) < 0)
//            .forEach(s -> System.out.println(s.getFirstName() + " " + s.getLastName()));

        // Task_03_Students by Age
//        students.stream()
//            .filter(s -> s.getAge() >= 18 && s.getAge() <= 24)
//            .forEach(s -> System.out.println(s.getFirstName() + " " + s.getLastName() + " " + s.getAge()));

        // Task_04_Sort Students
//        Comparator<Student> lastAscending =
//            (s1, s2) -> s1.getLastName().compareTo(s2.getLastName());
//
//        Comparator<Student> studentComparator =
//            lastAscending.thenComparing(
//                (s1, s2) -> s2.getFirstName().compareTo(s1.getFirstName())
//            );
//
//        students.stream()
//            .sorted(studentComparator)
//            .forEach(s -> System.out.println(s.getFirstName() + " " + s.getLastName()));

        // Task_05_Filter Students by Email Domain
//        students.stream()
//            .filter(s -> s.getEmail().substring(s.getEmail().indexOf("@")).equals("@gmail.com"))
//            .forEach(s -> System.out.println(s.getFirstName() + " " + s.getLastName() + " " + s.getEmail()));

        // Task_06_Filter Students by Phone
//        students.stream()
//            .filter(s -> s.getPhone().startsWith("02") || s.getPhone().startsWith("+3592"))
//            .forEach(s -> System.out.println(s.getFirstName() + " " + s.getLastName() + " " + s.getPhone()));

        // Task_07_Excellent Students
//        students.stream()
//            .filter(s -> s.getGrades().contains(6))
//            .forEach(s -> {
//                System.out.print(s.getFirstName() + " " + s.getLastName() + " ");
//                s.getGrades().stream()
//                    .sorted((g1, g2) -> g2.compareTo(g1))
//                    .forEach(g -> System.out.print(g + " "));
//                System.out.println();
//            });

        // Task_08_Weak Students
//        Predicate<Student> weakStudents = s -> {
//            int weakIndex = 0;
//            for (Integer grade : s.getGrades()) {
//                if (grade <= 3)
//                    weakIndex++;
//            }
//            return weakIndex >= 2;
//        };
//        Comparator<Student> compareWeakStudents =
//            (s1, s2) -> Integer.compare(
//                    s1.getGrades().stream().mapToInt(Integer::intValue).sum(),
//                    s2.getGrades().stream().mapToInt(Integer::intValue).sum());
//
//
//        students.stream()
//            .filter(weakStudents)
//            .sorted(compareWeakStudents)
//            .forEach(s -> {
//                System.out.print(s.getFirstName() + " " + s.getLastName() + " ");
//                s.getGrades().stream()
//                    .sorted()
//                    .forEach(g -> System.out.print(g + " "));
//                System.out.println();
//            });

        // Task_09_Students by Enrollment Year
        Map<Integer, List<Student>> studentsByYear =
            students.stream()
            .collect(Collectors.groupingBy(
                s -> Integer.valueOf(
                    s.getFacultyNumber().substring(s.getFacultyNumber().length() - 2)
                )
            ));

        studentsByYear.entrySet().stream()
            .sorted((y1, y2) -> y1.getKey().compareTo(y2.getKey()))
            .forEach(y -> {
                System.out.println("20" + y.getKey() + ":");
                y.getValue().stream()
                    .sorted((s1, s2) -> (s1.getFirstName() + " "+ s1.getLastName()).compareTo(s2.getFirstName() + " "+ s2.getLastName()))
                    .forEach(s -> System.out.printf("-- %s %s\n", s.getFirstName(), s.getLastName()));
            });
    }
}
