import java.util.HashMap;
import java.util.Scanner;

public class task_04_SpecialWords {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String[] keys = scanner.nextLine().split("\\s+");
        HashMap<String, Integer> words = new HashMap<>();
        for (String key : keys) {
            words.put(key, 0);
        }
        String text = scanner.nextLine();
        String[] params = text.split("\\s+");
        for (String param : params) {
            if (words.containsKey(param)) {
                words.put(param, words.get(param) + 1);
            }
        }

        for (String s : words.keySet()) {
            System.out.println(s + " - " + words.get(s));
        }
    }
}
