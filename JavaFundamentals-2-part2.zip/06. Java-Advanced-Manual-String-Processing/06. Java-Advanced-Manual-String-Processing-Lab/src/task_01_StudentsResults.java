import java.lang.reflect.AnnotatedArrayType;
import java.util.*;

public class task_01_StudentsResults {
    public static void main(String[] args) {
        //Locale.setDefault(Locale.ROOT);
        Scanner scanner = new Scanner(System.in);
        int lines = Integer.parseInt(scanner.nextLine());

        TreeMap<String, List<Double>> students = new TreeMap<>();
        for (int i = 0; i < lines; i++) {
            String[] input = scanner.nextLine().split(" - ");
            String name = input[0];
            String[] grades = input[1].split(", ");

            List<Double> examResults = new ArrayList<>();
            double sum = 0;
            for (String grade : grades) {
                double gr = Double.parseDouble(grade);
                sum += gr;
                examResults.add(gr);
            }

            examResults.add(sum / 3);
            students.put(name, examResults);
        }

        if (lines != 0) {
            System.out.println(String.format(
                    "%1$-10s|%2$7s|%3$7s|%4$7s|%5$7s|", "Name", "JAdv", "JavaOOP", "AdvOOP", "Average"));
            for (String student : students.keySet()) {
                System.out.println(
                        String.format("%1$-10s|%2$7.2f|%3$7.2f|%4$7.2f|%5$7.4f|",
                                student,
                                students.get(student).get(0),
                                students.get(student).get(1),
                                students.get(student).get(2),
                                students.get(student).get(3)
                        ).replace('.', ','));
            }
        }
    }
}

