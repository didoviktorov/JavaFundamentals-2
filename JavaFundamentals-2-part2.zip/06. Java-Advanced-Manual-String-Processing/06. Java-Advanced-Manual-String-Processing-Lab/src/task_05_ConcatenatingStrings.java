import java.util.Scanner;

public class task_05_ConcatenatingStrings {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int number = Integer.parseInt(scanner.nextLine());
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < number; i++) {
            sb.append(scanner.nextLine()).append(" ");
        }
        System.out.println(sb.toString().trim());
    }
}
