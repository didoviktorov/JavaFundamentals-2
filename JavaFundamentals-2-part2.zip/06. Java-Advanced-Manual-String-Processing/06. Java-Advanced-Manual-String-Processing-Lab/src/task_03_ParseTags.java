import java.util.Scanner;

public class task_03_ParseTags {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        String text = scanner.nextLine();
        String openTag = "<upcase>";
        String closeTag = "</upcase>";
        int firstIndex = text.indexOf(openTag);
        int secondIndex = text.indexOf(closeTag);
        while (firstIndex != -1 && secondIndex != -1) {
            String begin = text.substring(0, firstIndex);
            String upper = text.substring(firstIndex + openTag.length(), secondIndex).toUpperCase();
            String lastPart = text.substring(secondIndex + closeTag.length());
            text = begin + upper + lastPart;

            firstIndex = text.indexOf(openTag);
            secondIndex = text.indexOf(closeTag);
        }

        System.out.println(text);
    }
}
