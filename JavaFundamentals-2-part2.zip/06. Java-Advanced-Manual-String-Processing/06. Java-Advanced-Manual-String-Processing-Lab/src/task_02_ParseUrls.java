import java.util.Scanner;

public class task_02_ParseUrls {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String line = scanner.nextLine();
        String[] params = line.split("://");
        if (params.length != 2) {
            System.out.println("Invalid URL");
        } else {
            String url = line.substring(0, line.indexOf("://")).trim();
            line = line.substring(line.indexOf("://") + 3);
            String server = line.substring(0, line.indexOf("/")).trim();
            String resources = line.substring(line.indexOf("/") + 1).trim();
            System.out.println(String.format("Protocol = %1s\nServer = %2s\nResources = %3s\n", url, server, resources));
        }
    }
}
