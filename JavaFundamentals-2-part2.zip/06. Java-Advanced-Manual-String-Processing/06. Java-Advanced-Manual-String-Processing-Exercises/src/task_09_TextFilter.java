import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class task_09_TextFilter {
    public static void main(String[] args) throws IOException {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        String[] banWords = br.readLine().split(", ");
        String text = br.readLine();
        for (String banWord : banWords) {
            text = text.replaceAll(banWord, new String(new char[banWord.length()]).replace("\0", "*"));
        }
        System.out.println(text);
    }
}
