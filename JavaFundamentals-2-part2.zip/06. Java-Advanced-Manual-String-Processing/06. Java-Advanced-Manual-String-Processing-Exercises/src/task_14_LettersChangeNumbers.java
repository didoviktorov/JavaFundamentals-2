import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.math.BigDecimal;


public class task_14_LettersChangeNumbers {
    public static void main(String[] args) throws IOException {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        String[] params = br.readLine().trim().split("\\s+");
        String alphabet = " abcdefghijklmnopqrstuvwxyz";
        BigDecimal sum = BigDecimal.ZERO;
        for (int index = 0; index < params.length; index++) {
            StringBuilder str = new StringBuilder(params[index]);
            char firstLetter = str.charAt(0);
            char secondLetter = str.charAt(str.length() - 1);
            double currentNumber = Double.parseDouble(str.substring(1, str.length() - 1));
            if (Character.isUpperCase(firstLetter)) {
                double divisor = Double.parseDouble(alphabet.indexOf((firstLetter + "").toLowerCase())+"");
                currentNumber /= divisor;
            } else {
                double multiplier = Double.parseDouble(alphabet.indexOf(firstLetter) + "");
                currentNumber *= multiplier;
            }
            if (Character.isUpperCase(secondLetter)) {
                Double subtract = Double.parseDouble(alphabet.indexOf((secondLetter + "").toLowerCase())+"");
                currentNumber -= subtract;
            } else {
                int add = alphabet.indexOf(secondLetter);
                currentNumber += add;
            }
            sum = sum.add(new BigDecimal(currentNumber));
        }

        System.out.println(String.format("%.2f", sum));
    }
}
