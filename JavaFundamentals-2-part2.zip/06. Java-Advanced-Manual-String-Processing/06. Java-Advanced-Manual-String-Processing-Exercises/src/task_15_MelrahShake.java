import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class task_15_MelrahShake {
    public static void main(String[] args) throws IOException {

        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

        StringBuilder str = new StringBuilder(br.readLine());
        StringBuilder shake = new StringBuilder(br.readLine());

        while (true) {
            int startIndex = str.toString().indexOf(shake.toString());
            int endIndex = str.toString().lastIndexOf(shake.toString());
            if (startIndex != endIndex && shake.length() > 0) {
                StringBuilder newStr = new StringBuilder();
                newStr.append(str.substring(0, startIndex));
                newStr.append(str.substring(startIndex + shake.length(), endIndex));
                newStr.append(str.substring(endIndex + shake.length()));

                str = newStr;
                shake = shake.deleteCharAt(shake.length() / 2);
                System.out.println("Shaked it.");
            } else {
                System.out.println("No shake.");
                System.out.println(str);
                break;
            }
        }
    }
}
