import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class task_06_CountSubstringOccurrences {
    public static void main(String[] args) throws IOException {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        String text = br.readLine().toLowerCase();
        String word = br.readLine().toLowerCase();

        int occurrences = 0;
        while (text.indexOf(word) > - 1) {
            text = text.substring(text.indexOf(word) + 1);
            occurrences++;
        }
        System.out.println(occurrences);
    }
}
