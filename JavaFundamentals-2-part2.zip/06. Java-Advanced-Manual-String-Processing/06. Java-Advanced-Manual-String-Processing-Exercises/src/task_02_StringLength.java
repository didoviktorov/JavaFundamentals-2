import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class task_02_StringLength {
    public static void main(String[] args) throws IOException {
        BufferedReader bf = new BufferedReader(new InputStreamReader(System.in));
        String line = bf.readLine();
        String replace = "*";
        StringBuilder sb = new StringBuilder(line);
        if (sb.length() > 20) {
            System.out.println(sb.substring(0, 20));
        } else {
            sb.append(new String(new char[20 - sb.length()]).replace("\0", replace));
            System.out.println(sb);
        }
    }
}
