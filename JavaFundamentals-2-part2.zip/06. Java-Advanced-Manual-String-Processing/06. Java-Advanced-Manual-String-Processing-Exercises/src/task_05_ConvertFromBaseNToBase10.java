import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.math.BigInteger;

public class task_05_ConvertFromBaseNToBase10 {
    public static void main(String[] args) throws IOException {
        BufferedReader bf = new BufferedReader(new InputStreamReader(System.in));
        String[] line = bf.readLine().trim().split("\\s+");
        int baseNumber = Integer.parseInt(line[0]);
        BigInteger number = new BigInteger(line[1]);

        char[] arr = number.toString().toCharArray();
        int base = arr.length - 1;
        BigInteger result = new BigInteger("0");
        for (int i = 0; i < arr.length; i++) {
            BigInteger currentNumber = new BigInteger(arr[i] + "");
            BigInteger multiplier = new BigInteger(baseNumber + "").pow(base);
            BigInteger c = currentNumber.multiply(multiplier);
            result = result.add(c);
            base--;
        }
        System.out.println(result);
    }
}
