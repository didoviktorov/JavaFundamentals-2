import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class task_12_CharacterMultiplier {
    public static void main(String[] args) throws IOException {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

        String[] words = br.readLine().trim().split("\\s+");
        String wA = words[0];
        String wB = words[1];

        int maxLength = Integer.max(wA.length(), wB.length());
        int minLength = Integer.min(wA.length(), wB.length());

        long sum = 0;
        for (int index = 0; index < maxLength; index++) {
            if (index < minLength) {
                sum += wA.charAt(index) * wB.charAt(index);
            } else {
                if (wA.length() == maxLength) {
                    sum += wA.charAt(index);
                } else {
                    sum += wB.charAt(index);
                }
            }
        }

        System.out.println(sum);
    }
}
