import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class task_08_MultiplierBigNumber {
    public static void main(String[] args) throws IOException {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        String firstNum = br.readLine();
        int secondNum = Integer.parseInt(br.readLine());
        int leadingZeroIndex = firstNum.indexOf("0");
        while (leadingZeroIndex == 0) {
            firstNum = firstNum.substring(leadingZeroIndex + 1);

            leadingZeroIndex = firstNum.indexOf("0");
        }

        if (firstNum.equals("0") || secondNum == 0 || firstNum.equals("")) {
            System.out.println(0);
            return;
        }

        StringBuilder result = new StringBuilder();
        int reminder = 0;
        for (int i = firstNum.length() - 1; i >= 0; i--) {
             int currentNum = Integer.parseInt(firstNum.charAt(i) + "");
             int currentResult = (currentNum * secondNum) + reminder;
             if (currentResult > 9) {
                 String s = String.valueOf(currentResult);
                 result.append(s.charAt(1));
                 reminder = Integer.parseInt(s.charAt(0) + "");
             } else {
                 result.append(currentResult);
                 reminder = 0;
             }
        }

        if (reminder != 0) {
            result.append(reminder);
        }
        System.out.println(result.reverse());
    }
}
