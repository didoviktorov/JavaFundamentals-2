import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.math.BigInteger;

public class task_04_ConvertFromBase10ToBaseN {
    public static void main(String[] args) throws IOException {
        BufferedReader bf = new BufferedReader(new InputStreamReader(System.in));
        String[] line = bf.readLine().trim().split("\\s+");
        int n = Integer.parseInt(line[0]);
        BigInteger base10 = new BigInteger(line[1]);
        StringBuilder baseN = new StringBuilder();

        while (base10.compareTo(new BigInteger("0")) > 0) {
            BigInteger reminder = base10.divideAndRemainder(new BigInteger(n + ""))[1];
            BigInteger divide = base10.divideAndRemainder(new BigInteger(n + ""))[0];
            baseN.insert(0, reminder);
            base10 = divide;
        }
        System.out.println(baseN);
    }
}
