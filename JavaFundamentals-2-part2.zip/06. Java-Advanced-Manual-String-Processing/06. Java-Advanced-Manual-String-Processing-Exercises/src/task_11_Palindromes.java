import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.*;
import java.util.stream.Collectors;

public class task_11_Palindromes {
    public static void main(String[] args) throws IOException {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        String[] words = br.readLine().trim().split("[ ,.?!]");
        TreeSet<String> palindromes = new TreeSet<>();
        for (String word : words) {
            if (!word.equals("")) {
                StringBuilder w = new StringBuilder(word);
                if (w.toString().equals(w.reverse().toString())) {
                    palindromes.add(word);
                }
            }
        }
        LinkedHashSet<String> sorted = palindromes
                .stream().sorted((a, b) -> a.toLowerCase().compareTo(b.toLowerCase()))
                .collect(Collectors.toCollection(LinkedHashSet::new));
        System.out.println(sorted);
    }
}
