import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class task_07_SumBigNumbers {
    public static void main(String[] args) throws IOException {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        String firstNum = br.readLine();
        String secondNum = br.readLine();

        int maxLength = Integer.max(firstNum.length(), secondNum.length());
        if (firstNum.length() < maxLength) {
            firstNum = new String(new char[maxLength - firstNum.length()]).replace("\0", "0") + firstNum;
        }
        if (secondNum.length() < maxLength) {
            secondNum = new String(new char[maxLength - secondNum.length()]).replace("\0", "0") + secondNum;
        }

        boolean reminder = false;
        String result = "";
        for (int i = maxLength - 1; i >= 0; i--) {
            int currentNumA = Integer.parseInt(firstNum.substring(i, i + 1));
            int currentNumB = Integer.parseInt(secondNum.substring(i, i + 1));
            int currentSum =  currentNumA + currentNumB;

            currentSum += (reminder ? 1 : 0);
            reminder = false;

            if (currentSum > 9) {
                reminder = true;
                currentSum -= 10;
            }
            result = currentSum + result;
        }

        if (reminder) {
            result = 1 + result;
        }
        int zeroIndex = result.indexOf("0");
        while (zeroIndex == 0) {
            result = result.substring(zeroIndex + 1);
            zeroIndex = result.indexOf("0");
        }
        System.out.println(result);

    }
}
