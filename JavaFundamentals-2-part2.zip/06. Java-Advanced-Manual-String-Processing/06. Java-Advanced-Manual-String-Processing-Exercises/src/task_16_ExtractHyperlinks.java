import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class task_16_ExtractHyperlinks {
    public static void main(String[] args) throws IOException {

        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        Pattern pattern = Pattern.compile("(?:<a)(?:[\\s\\n_0-9a-zA-Z=\"\"()]*?.*?)(?:href([\\s\\n]*)?=(?:['\"\"\\s\\n]*)?)([a-zA-Z:#\\/._\\-0-9!?=^+]*(\\([\"\"'a-zA-Z\\s.()0-9]*\\))?)(?:[\\s\\na-zA-Z=\"\"()0-9]*.*?)?(?:\\>)");
        Matcher matcher;
        String line  = br.readLine();
        while (!line.equals("END")) {
            matcher = pattern.matcher(line);
            if (matcher.find()) {
                for (int i = 1; i < matcher.groupCount(); i++)
                {
                    if (matcher.group(i) != null)
                    {
                        System.out.println((matcher.group(i)));
                    }
                }
            }
            line = br.readLine();
        }
    }
}
