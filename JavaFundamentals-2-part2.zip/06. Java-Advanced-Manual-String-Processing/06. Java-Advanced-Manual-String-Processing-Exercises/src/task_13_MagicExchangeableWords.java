import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.LinkedHashMap;

public class task_13_MagicExchangeableWords {
    public static void main(String[] args) throws IOException {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

        String[] words = br.readLine().trim().split("\\s+");
        String wA = words[0];
        String wB = words[1];
        boolean exchangeable = false;
        if (wA.length() >= wB.length()) {
            exchangeable = isExchangeable(wA, wB);
        } else {
            exchangeable = isExchangeable(wB, wA);
        }
        System.out.println(exchangeable);
    }

    private static boolean isExchangeable(String wA, String wB) {
        LinkedHashMap<Character, Character> symbols = new LinkedHashMap<>();
        boolean exchangeable = true;
        for (int i = 0; i < wB.length(); i++) {
            char a = wA.charAt(i);
            char b = wB.charAt(i);
            if (!symbols.containsKey(a)) {
                symbols.put(a, b);
            } else if (symbols.get(a) != b) {
                exchangeable = false;
                return exchangeable;
            }
        }

        for (int i = wB.length(); i < wA.length(); i++) {
            char a = wA.charAt(i);
            if (!symbols.containsKey(a)) {
                exchangeable = false;
                return exchangeable;
            }

        }
        return  exchangeable;
    }
}
