import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class task_01_ReverseString {
    public static void main(String[] args) throws IOException {
        BufferedReader bf = new BufferedReader(new InputStreamReader(System.in));
        String line = bf.readLine();
        StringBuilder sb = new StringBuilder(line);
        System.out.println(sb.reverse());
    }
}
