import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class task_03_FormattingNumbers {
    public static void main(String[] args) throws IOException {
        BufferedReader bf = new BufferedReader(new InputStreamReader(System.in));
        String line = bf.readLine().trim();
        String[] nums = line.split("\\s+");
        int a = Integer.parseInt(nums[0]);
        double b = Double.parseDouble(nums[1]);
        double c = Double.parseDouble(nums[2]);

        String binary = Integer.toString(a, 2);
        while (binary.length() < 10) {
            binary = "0" + binary;
        }
        if (binary.length() > 10) {
            binary = binary.substring(0, 10);
        }
        StringBuilder sb = new StringBuilder();
        sb.append("|").append(String.format("%-10X", a));
        sb.append("|").append(binary);
        sb.append("|").append(String.format("%10.2f", b));
        sb.append("|").append(String.format("%-10.3f", c)).append("|");
        System.out.println(sb);
    }
}
