import java.io.*;

public class task_11_SerializeCustomObject {
    private final static String path = "/src/resources/course.ser";
    public static void main(String[] args) {
        String projectPath = System.getProperty("user.dir");
        String inputPath = projectPath + path;
        String outputPath = projectPath + path;

        try(ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(outputPath));
            ObjectInputStream ois = new ObjectInputStream(new FileInputStream(inputPath))) {
            Course course = new Course();
            course.name = "Java Fundamentals";
            course.students = 50;
            oos.writeObject(course);
            Course copiedCourse = (Course)ois.readObject();
            System.out.println("Copied course name: " + copiedCourse.name);
            System.out.println("Copied course students are: " + copiedCourse.students);
        } catch (IOException e) {
            System.out.println(e.getMessage());
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
    }
}
