import java.io.*;
import java.util.ArrayList;
import java.util.Collections;

public class task_04_CountCharacterType {
    private final static String path = "/src/resources/";
    public static void main(String[] args) {
        String projectPath = System.getProperty("user.dir");

        String inputPath = projectPath + path + "inputTask_04.txt";
        String outputPath = projectPath + path + "outputTask_04.txt";

        ArrayList<Character> punctuation = new ArrayList<>();
        Collections.addAll(punctuation, ',', '.', '!', '?');
        ArrayList<Character> vowels = new ArrayList<>();
        Collections.addAll(vowels, 'a', 'e', 'i', 'o', 'u');

        long vowelsCount = 0;
        long consonantsCount = 0;
        long punctuationCount = 0;
        try (BufferedReader reader = new BufferedReader(new FileReader(inputPath));
             PrintWriter writer = new PrintWriter(new FileWriter(outputPath))){
            int oneByte = reader.read();
            while (oneByte >= 0) {
                if (punctuation.contains((char)oneByte)) {
                    punctuationCount++;
                } else if (vowels.contains((char)oneByte)) {
                    vowelsCount++;
                } else if (Character.isLetter((char)oneByte)) {
                    consonantsCount++;
                }

                oneByte = reader.read();
            }
            writer.println("Vowels: " + vowelsCount);
            writer.println("Consonants: " + consonantsCount);
            writer.println("Punctuation: " + punctuationCount);
            System.out.println("Vowels: " + vowelsCount);
            System.out.println("Consonants: " + consonantsCount);
            System.out.println("Punctuation: " + punctuationCount);
        } catch (IOException e) {
            System.out.println(e.getMessage());
        }

    }
}
