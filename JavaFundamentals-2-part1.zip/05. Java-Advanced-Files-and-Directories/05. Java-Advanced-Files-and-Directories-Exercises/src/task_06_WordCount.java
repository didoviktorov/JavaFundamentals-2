import java.io.*;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.stream.Collectors;

public class task_06_WordCount {
    private final static String path = "/src/resources/";
    public static void main(String[] args) {
        String projectPath = System.getProperty("user.dir");

        String wordsPath = projectPath + path + "words.txt";
        String textPath = projectPath + path + "text.txt";
        String outputPath = projectPath + path + "result.txt";

        LinkedHashMap<String, Integer> wordsToLower = new LinkedHashMap<>();
        HashSet<String> words = new HashSet<>();
        try (BufferedReader readWords = new BufferedReader(new FileReader(wordsPath));
                BufferedReader readText = new BufferedReader(new FileReader(textPath));
                PrintWriter writer = new PrintWriter(new FileWriter(outputPath))){
            String line = readWords.readLine();
            while (line != null) {
                String[] arr = line.split("\\s+");
                for (String w : arr) {
                    wordsToLower.put(w.toLowerCase(), 0);
                    words.add(w);
                }
                line = readWords.readLine();
            }

            line = readText.readLine();
            while (line != null) {
                String[] textWords = line.toLowerCase().split("\\s+");
                for (String textWord : textWords) {
                    if (wordsToLower.containsKey(textWord)) {
                        wordsToLower.put(textWord, wordsToLower.get(textWord) + 1);
                    }
                }
                line = readText.readLine();
            }

            LinkedHashMap<String, Integer> sortedWords = wordsToLower.entrySet().stream()
                    .sorted((a, b) -> b.getValue() - a.getValue())
                    .collect(Collectors.toMap(
                            Map.Entry::getKey,
                            Map.Entry::getValue,
                            (x, y) -> {
                                throw new AssertionError();
                            },
                            LinkedHashMap::new
                    ));

            for (String key : sortedWords.keySet()) {
                for (String word : words) {
                    if (word.toLowerCase().equals(key)) {
                        writer.println(word + " - " + sortedWords.get(key));
                    }
                }
            }
        } catch (IOException e) {
            System.out.println(e.getMessage());
        }
    }
}
