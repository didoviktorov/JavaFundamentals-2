import java.io.*;

public class task_07_MergeFiles {
    private final static String path = "/src/resources/";
    public static void main(String[] args) {
        String projectPath = System.getProperty("user.dir");

        String fileOnePath = projectPath + path + "File1.txt";
        String fileTwoPath = projectPath + path + "File2.txt";
        String fileThreePath = projectPath + path + "File3.txt";
        String outputPath = projectPath + path + "MergedFile.txt";

        File[] files = { new File(fileOnePath), new File(fileTwoPath), new File(fileThreePath) };
        File result = new File(outputPath);

        try (PrintWriter writer = new PrintWriter(new FileWriter(result))){
            for (File file : files) {
                try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
                    String line = reader.readLine();
                    while (line != null) {
                        writer.println(line);
                        line = reader.readLine();
                    }
                }

            }
        } catch (IOException e) {
            System.out.println(e.getMessage());
        }
    }
}
