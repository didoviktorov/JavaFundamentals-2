import java.io.*;

public class task_03_AllCapitals {
    private final static String path = "/src/resources/";
    public static void main(String[] args) {
        String projectPath = System.getProperty("user.dir");

        String inputPath = projectPath + path + "input.txt";
        String outputPath = projectPath + path + "allCapitals.txt";

        try (BufferedReader reader = new BufferedReader(new FileReader(inputPath));
             PrintWriter writer = new PrintWriter(new FileWriter(outputPath))){
            String line = reader.readLine();
            while (line != null) {
                writer.println(line.toUpperCase());
                line = reader.readLine();
            }
        } catch (IOException e) {
            System.out.println(e.getMessage());
        }
    }
}
