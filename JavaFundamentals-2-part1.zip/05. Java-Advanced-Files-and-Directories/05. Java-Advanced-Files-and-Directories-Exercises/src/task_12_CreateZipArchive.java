import java.io.*;
import java.util.zip.*;

public class task_12_CreateZipArchive {
    private final static String path = "/src/resources/";
    public static void main(String[] args) {
        String projectPath = System.getProperty("user.dir");
        File[] files = new File[3];
        files[0] = new File(projectPath + path + "File1.txt");
        files[1] = new File(projectPath + path + "File2.txt");
        files[2] = new File(projectPath + path + "File3.txt");

        String output = projectPath + path + "files.zip";

        try(ZipOutputStream zos = new ZipOutputStream(new FileOutputStream(output))) {
            for (int i = 0; i < files.length; i++) {
                File file = files[i];
                FileInputStream fis = new FileInputStream(file);
                zos.putNextEntry(new ZipEntry(file.getName()));

                int oneBye = 0;
                while((oneBye = fis.read()) != - 1) {
                    zos.write(oneBye);
                }
                fis.close();
            }
        } catch (IOException e) {
            System.out.println(e.getMessage());
        }
    }
}
