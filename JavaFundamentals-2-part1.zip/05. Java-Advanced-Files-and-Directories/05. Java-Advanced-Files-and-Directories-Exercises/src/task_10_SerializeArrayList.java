import java.io.*;
import java.util.ArrayList;
import java.util.Collections;

public class task_10_SerializeArrayList {
    private final static String path = "/src/resources/list.ser";
    public static void main(String[] args) {
        String projectPath = System.getProperty("user.dir");
        String inputPath = projectPath + path;
        String outputPath = projectPath + path;

        ArrayList<Double>  doubles = new ArrayList<>();
        Collections.addAll(doubles, 12.3d, 11.589d, 1d, -28.8d);

        try(ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(outputPath));
                ObjectInputStream ois = new ObjectInputStream(new FileInputStream(inputPath))) {
            oos.writeObject(doubles);
            ArrayList<Double> newDoubles = (ArrayList<Double>)ois.readObject();
            // print if two lists are equal
            System.out.println(newDoubles.equals(doubles));
        } catch (IOException e) {
            System.out.println(e.getMessage());
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
    }
}
