import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class task_02_SumBytes {
    private final static String path = "/src/resources/";
    public static void main(String[] args) {
        String projectPath = System.getProperty("user.dir");
        String inputPath = projectPath + path + "task_01_02.txt";

        try (BufferedReader reader = new BufferedReader(new FileReader(inputPath))){
            String line = reader.readLine();
            Long sumBytes = 0l;
            while (line != null) {
                char[] arr = line.toCharArray();
                for (char c : arr) {
                    sumBytes += c;
                }
                line = reader.readLine();
            }
            System.out.println(sumBytes);
        } catch (IOException e) {
            System.out.println(e.getMessage());
        }
    }
}
