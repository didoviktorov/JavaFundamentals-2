import java.io.File;
import java.util.ArrayDeque;

public class task_08_GetFolderSize {
    private final static String path = "/src/Files-and-Streams";
    public static void main(String[] args) {
        String projectPath = System.getProperty("user.dir");
        String folderPath = projectPath + path;

        File file = new File(folderPath);
        long size = 0L;
        ArrayDeque<File> folders = new ArrayDeque<>();
        folders.offer(file);
        while (!folders.isEmpty()) {
            File f = folders.poll();
            if (f.isDirectory()) {
                File[] files = f.listFiles();
                for (File file1 : files) {
                    if (file1.isDirectory()) {
                        folders.offer(file1);
                    } else {
                        size += file1.length();
                    }
                }
            }
        }
        System.out.println("Folder size: " + size);
    }
}
