import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class task_01_SumLines {
    private final static String path = "/src/resources/";
    public static void main(String[] args) {
        String projectPath = System.getProperty("user.dir");
        String inputPath = projectPath + path + "task_01_02.txt";

        try (BufferedReader reader = new BufferedReader(new FileReader(inputPath))){
            String line = reader.readLine();
            while (line != null) {
                int sumLine = 0;
                char[] arr = line.toCharArray();
                for (int i = 0; i < arr.length; i++) {
                    sumLine += arr[i];

                }
                System.out.println(sumLine);
                line = reader.readLine();
            }
        } catch (IOException e) {
            System.out.println(e.getMessage());
        }
    }
}
