import java.io.*;

public class task_09_CopyAPicture {
    private final static String path = "/src/resources/img.jpg";
    public static void main(String[] args) {
        String projectPath = System.getProperty("user.dir");
        String picturePath = projectPath + path;
        String outputPath = projectPath + "/src/resources/picture-copy.jpg";

        try (FileInputStream fis = new FileInputStream(picturePath);
                FileOutputStream fos = new FileOutputStream(outputPath)) {
            byte[] buffer = new byte[1024];
            int currentByte = 0;
            while ((currentByte = fis.read(buffer)) != -1) {
                fos.write(buffer, 0, currentByte);
            }
        } catch (IOException e) {
            System.out.println(e.getMessage());
        }
    }
}
