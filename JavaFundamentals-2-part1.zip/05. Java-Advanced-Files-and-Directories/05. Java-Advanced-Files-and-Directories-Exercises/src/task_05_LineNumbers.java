import java.io.*;

public class task_05_LineNumbers {
    private final static String path = "/src/resources/";
    public static void main(String[] args) {
        String projectPath = System.getProperty("user.dir");

        String inputPath = projectPath + path + "input.txt";
        String outputPath = projectPath + path + "outputTask_05.txt";

        int lineNumber = 1;
        try (BufferedReader reader = new BufferedReader(new FileReader(inputPath));
             PrintWriter writer = new PrintWriter(new FileWriter(outputPath))){
            String line = reader.readLine();
            while (line != null) {
                writer.println(lineNumber + ". " + line);
                lineNumber++;
                line = reader.readLine();
            }
        } catch (IOException e) {
            System.out.println(e.getMessage());
        }
    }
}
