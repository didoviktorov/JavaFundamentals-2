import java.io.Serializable;

public class Course implements Serializable {
    String name;
    int students;
}
