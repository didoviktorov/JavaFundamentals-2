import com.sun.corba.se.pept.encoding.OutputObject;

import java.io.*;

public class task_09_SerializeCustomObject {
    public static void main(String[] args) {
        final String outPath = "D:\\Software\\JavaFundamentals-2\\05. Java-Advanced-Files-and-Directories\\" +
                "05. Java-Advanced-Files-and-Directories-Lab\\resources\\Serialize.ser";

        Cube cube = new Cube();
        cube.color = "green";
        cube.width = 15.3d;
        cube.height = 12.4d;
        cube.depth = 3d;

        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(outPath));
             ObjectInputStream ois = new ObjectInputStream(new FileInputStream(outPath))) {
            oos.writeObject(cube);

            Cube newCube = (Cube)ois.readObject();
            System.out.println(newCube.color);
        } catch (IOException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
    }
}
