import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

public class task_03_CopyBytes {
    public static void main(String[] args) {
        String path =
                "D:\\Software\\JavaFundamentals-2\\05. Java-Advanced-Files-and-Directories\\" +
                        "05. Java-Advanced-Files-and-Directories-Lab\\resources\\input.txt";
        String outPath = "D:\\Software\\JavaFundamentals-2\\05. Java-Advanced-Files-and-Directories\\" +
                "05. Java-Advanced-Files-and-Directories-Lab\\resources\\outputBytes.txt";


        try (FileInputStream fis = new FileInputStream(path);
             FileOutputStream fos = new FileOutputStream(outPath)){
            int oneByte = fis.read();
            //fos.flush();
            while (oneByte >= 0) {
                if (oneByte == ' ' || oneByte == '\n') {
                    fos.write(oneByte);
                } else {
                    String b = String.valueOf(oneByte);
                    for (int i = 0; i < b.length(); i++) {
                        fos.write(b.charAt(i));
                    }
                }
                oneByte = fis.read();
            }
        } catch (IOException e) {
            System.out.println(e.getMessage());
        }
    }
}
