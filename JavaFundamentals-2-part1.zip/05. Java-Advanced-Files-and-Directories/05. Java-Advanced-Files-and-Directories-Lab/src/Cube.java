import java.io.Serializable;

public class Cube implements Serializable {
    String color;
    double width;
    double height;
    double depth;
}
