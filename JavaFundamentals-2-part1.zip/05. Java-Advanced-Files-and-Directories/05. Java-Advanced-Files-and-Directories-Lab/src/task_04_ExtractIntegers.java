import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.PrintWriter;
import java.util.Scanner;

public class task_04_ExtractIntegers {
    public static void main(String[] args) {
        String path =
                "D:\\Software\\JavaFundamentals-2\\05. Java-Advanced-Files-and-Directories\\" +
                        "05. Java-Advanced-Files-and-Directories-Lab\\resources\\input.txt";
        String outPath = "D:\\Software\\JavaFundamentals-2\\05. Java-Advanced-Files-and-Directories\\" +
                "05. Java-Advanced-Files-and-Directories-Lab\\resources\\outputIntegers.txt";

        try (Scanner reader = new Scanner(new FileInputStream(path));
                PrintWriter out = new PrintWriter(outPath))
        {
            while (reader.hasNext()) {
                if (reader.hasNextInt()) {
                    out.println(reader.nextInt());
                }
                reader.next();
            }
        } catch (FileNotFoundException e) {
            System.out.println(e.getMessage());
        }
    }
}
