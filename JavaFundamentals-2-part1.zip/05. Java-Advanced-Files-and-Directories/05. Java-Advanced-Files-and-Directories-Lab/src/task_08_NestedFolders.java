import java.io.File;
import java.util.ArrayDeque;

public class task_08_NestedFolders {
    public static void main(String[] args) {
        String inPath = "D:\\Software\\JavaFundamentals-2\\05. Java-Advanced-Files-and-Directories\\" +
                "05. Java-Advanced-Files-and-Directories-Lab\\resources\\Files-and-Streams";
        File file = new File(inPath);
        int countFolders = 0;
        ArrayDeque<File> folders = new ArrayDeque<>();
        folders.offer(file);
        while (!folders.isEmpty()) {
            countFolders++;
            File f = folders.poll();
            if (f.isDirectory()) {
                System.out.println(f.getName());
                File[] files = f.listFiles();
                for (File file1 : files) {
                    if (file1.isDirectory()) {
                        folders.offer(file1);
                    }
                }
            }
        }
        System.out.println(countFolders + " folders");
    }
}
