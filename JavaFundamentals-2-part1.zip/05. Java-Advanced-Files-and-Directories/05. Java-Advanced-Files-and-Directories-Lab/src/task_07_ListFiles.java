import java.io.File;

public class task_07_ListFiles {
    public static void main(String[] args) {
        String inPath = "D:\\Software\\JavaFundamentals-2\\05. Java-Advanced-Files-and-Directories\\" +
                "05. Java-Advanced-Files-and-Directories-Lab\\resources\\Files-and-Streams";
        File file = new File(inPath);

        if (file.isDirectory()) {
            File[] files = file.listFiles();
            for (File f : files) {
                if (!f.isDirectory()) {
                    System.out.println(f.getName() + ": " + f.length());
                }
            }
        }
    }
}
