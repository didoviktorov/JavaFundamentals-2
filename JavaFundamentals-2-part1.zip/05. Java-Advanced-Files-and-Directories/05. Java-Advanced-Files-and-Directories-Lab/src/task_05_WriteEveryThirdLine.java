import com.sun.xml.internal.ws.policy.privateutil.PolicyUtils;

import java.io.*;
import java.util.Scanner;

public class task_05_WriteEveryThirdLine {
    public static void main(String[] args) {
        String path =
                "D:\\Software\\JavaFundamentals-2\\05. Java-Advanced-Files-and-Directories\\" +
                        "05. Java-Advanced-Files-and-Directories-Lab\\resources\\input.txt";
        String outPath = "D:\\Software\\JavaFundamentals-2\\05. Java-Advanced-Files-and-Directories\\" +
                "05. Java-Advanced-Files-and-Directories-Lab\\resources\\outputThreeLines.txt";

        try (BufferedReader reader = new BufferedReader(new FileReader(path));
                PrintWriter writer = new PrintWriter(new FileWriter(outPath))) {
            int counter = 1;
            String line = reader.readLine();
            while (line != null){
                if (counter % 3 == 0) {
                    writer.println(line);
                }
                counter++;
                line = reader.readLine();
            }
        } catch (IOException e) {
            System.out.println(e.getMessage());
        }
    }
}
