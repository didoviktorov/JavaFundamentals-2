import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;

public class task_02_WriteToAFile {
    public static void main(String[] args) {
        String path =
                "D:\\Software\\JavaFundamentals-2\\05. Java-Advanced-Files-and-Directories\\" +
                        "05. Java-Advanced-Files-and-Directories-Lab\\resources\\input.txt";
        String outPath = "D:\\Software\\JavaFundamentals-2\\05. Java-Advanced-Files-and-Directories\\" +
                "05. Java-Advanced-Files-and-Directories-Lab\\resources\\output.txt";


        ArrayList<Character> punctuation = new ArrayList<>();
        Collections.addAll(punctuation, ',', '.', '!', '?');

        try (FileInputStream fis = new FileInputStream(path);
                FileOutputStream fos = new FileOutputStream(outPath)){
            int oneByte = fis.read();
            //fos.flush();
            while (oneByte >= 0) {
                if (!punctuation.contains((char)oneByte)) {
                    fos.write(oneByte);
                }
                oneByte = fis.read();
            }
        } catch (IOException e) {
            System.out.println(e.getMessage());
        }
    }
}
