import java.io.FileInputStream;
import java.io.IOException;

public class task_01_ReadFile {
    public static void main(String[] args) {
        String path =
                "D:\\Software\\JavaFundamentals-2\\05. Java-Advanced-Files-and-Directories\\" +
                        "05. Java-Advanced-Files-and-Directories-Lab\\resources\\input.txt";

        try (FileInputStream fis = new FileInputStream(path)){
            int oneByte = fis.read();
            while (oneByte >= 0) {
                System.out.printf("%s ", Integer.toBinaryString(oneByte));
                oneByte = fis.read();
            }
        } catch (IOException e) {
            System.out.println(e.getMessage());
        }
    }
}
