import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Collections;
import java.util.List;

public class task_06_SortLines {
    public static void main(String[] args) {
        final String inPath = "D:\\Software\\JavaFundamentals-2\\05. Java-Advanced-Files-and-Directories\\" +
                "05. Java-Advanced-Files-and-Directories-Lab\\resources\\input.txt";
        final String outPath = "D:\\Software\\JavaFundamentals-2\\05. Java-Advanced-Files-and-Directories\\" +
                "05. Java-Advanced-Files-and-Directories-Lab\\resources\\sortLines.txt";

        Path in = Paths.get(inPath);
        Path out = Paths.get(outPath);

        try {
            List<String> lines = Files.readAllLines(in);
            Collections.sort(lines);
            Files.write(out, lines);

        } catch (IOException e) {
            System.out.println(e.getMessage());
        }

    }
}
