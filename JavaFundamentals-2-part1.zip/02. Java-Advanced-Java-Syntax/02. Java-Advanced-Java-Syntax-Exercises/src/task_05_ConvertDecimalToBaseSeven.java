import java.util.Scanner;

public class task_05_ConvertDecimalToBaseSeven {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int number = Integer.parseInt(scanner.nextLine());
        System.out.println(convertedNumber(number));
    }

    public static int convertedNumber (int num) {
        String convertedNumber = "";
        int maxBase = 0;
        while (Math.pow(7, maxBase) <= num) {
            maxBase++;
        }

        for (int i = maxBase; i > 0; i--) {
            convertedNumber += num / (int) Math.pow(7, i - 1);
            num = num % (int) Math.pow(7, i - 1);
        }

        int result = Integer.parseInt(convertedNumber);
        return result;
    }
}
