import java.util.Scanner;

public class task_09_CharacterMultiplier {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String[] strs = scanner.nextLine().split("\\s+");
        String a = strs[0];
        String b = strs[1];

        int maxLength = a.length();
        if (a.length() != b.length()) {
            if (b.length() > maxLength) {
                maxLength = b.length();
            }
        }

        long sum = 0;
        for (int i = 0; i < maxLength; i++) {
            if (i >= a.length()) {
                sum += b.charAt(i);
            } else if (i >= b.length()) {
                sum += a.charAt(i);
            } else {
                sum += a.charAt(i) * b.charAt(i);
            }

        }

        System.out.println(sum);
    }
}
