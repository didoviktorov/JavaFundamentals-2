import java.util.Scanner;

public class task_07_OddAndEvenPairs {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String[] nums = scanner.nextLine().split("\\s+");
        if (nums.length % 2 != 0) {
            System.out.println("invalid length");
        } else {
            int[] numbers = new int[nums.length];
            for (int i = 0; i < numbers.length; i++) {
                numbers[i] = Integer.parseInt(nums[i]);
            }

            for (int i = 0; i < numbers.length; i += 2) {
                int a = numbers[i];
                int b = numbers[i + 1];
                if (a % 2 == 0 && b % 2 == 0) {
                    System.out.printf("%d, %d -> both are even%n", a, b);
                } else if (a % 2 != 0 && b % 2 != 0) {
                    System.out.printf("%d, %d -> both are odd%n", a, b);
                } else {
                    System.out.printf("%d, %d -> different%n", a, b);
                }

            }
        }
    }
}
