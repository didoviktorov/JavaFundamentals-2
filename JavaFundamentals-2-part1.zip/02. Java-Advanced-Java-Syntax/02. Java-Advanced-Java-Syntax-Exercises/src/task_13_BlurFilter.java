import java.util.Scanner;

public class task_13_BlurFilter {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        Long blurAmount = Long.parseLong(scanner.nextLine());

        String[] dimensions = scanner.nextLine().split("\\s+");
        int rows = Integer.parseInt(dimensions[0]);
        int cols = Integer.parseInt(dimensions[1]);

        String[][] matrix = new String[rows][cols];
        for (int i = 0; i < rows; i++) {
            String[] line = scanner.nextLine().split("\\s+");
            for (int j = 0; j < cols; j++) {
                matrix[i][j] = line[j];
            }
        }

        String[] position = scanner.nextLine().split("\\s+");
        int positionRow = Integer.parseInt(position[0]);
        int positionCol = Integer.parseInt(position[1]);
        int minRow = positionRow - 1;
        if (minRow < 0) {
            minRow = 0;
        }

        int minCol = positionCol - 1;
        if (minCol < 0 ) {
            minCol = 0;
        }

        int maxRow = positionRow + 1;
        if (maxRow > rows - 1) {
            maxRow = rows - 1;
        }
        int maxCol = positionCol + 1;
        if (maxCol > cols - 1) {
            maxCol = cols - 1;
        }
        for (int row = minRow; row <= maxRow; row++) {
            for (int col = minCol; col <= maxCol; col++) {
                Long cell = Long.parseLong(matrix[row][col]) + blurAmount;
                matrix[row][col] = cell + "";
            }
        }

        for (int row = 0; row < rows; row++) {
            System.out.println(String.join(" ", matrix[row]));
        }
    }
}
