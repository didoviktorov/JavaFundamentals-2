import java.math.BigDecimal;
import java.util.Scanner;

public class task_01_RectangleArea {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        double a = scanner.nextDouble();
        double b = scanner.nextDouble();
        BigDecimal area = new BigDecimal(a * b);

        System.out.printf("%.2f", area);
    }
}
