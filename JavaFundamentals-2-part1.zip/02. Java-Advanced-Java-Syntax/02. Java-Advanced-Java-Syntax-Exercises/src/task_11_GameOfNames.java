import java.util.Scanner;

public class task_11_GameOfNames {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int numberOfPlayers = Integer.parseInt(scanner.nextLine());

        String winner = "";
        int scores = Integer.MIN_VALUE;
        for (int i = 0; i < numberOfPlayers * 2; i += 2) {
            String name = scanner.nextLine();
            int currentScores = Integer.parseInt(scanner.nextLine());
            int newScore = calculateScore(name, currentScores);
            if (newScore > scores) {
                winner = name;
                scores = newScore;
            }
        }

        System.out.printf("The winner is %s - %d points", winner, scores);
    }

    public static int calculateScore (String name, int scores) {
        int result = scores;
        for (int i = 0; i < name.length(); i++) {
             if (name.charAt(i) % 2 == 0) {
                 result += name.charAt(i);
             } else {
                 result -= name.charAt(i);
             }
        }

        return result;
    }
}
