import java.util.*;

public class task_12_VehiclePark {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        List<String> vehiclePark = new ArrayList<>(Arrays.asList(scanner.nextLine().split("\\s+")));
        String request = scanner.nextLine();
        int countSold = 0;
        while(!request.equals("End of customers!")) {
            String[] requestRow = request.toLowerCase().split("\\s+");
            String currentVehicle = requestRow[0];
            int seats = Integer.parseInt(requestRow[2]);
            String requested = currentVehicle.charAt(0) + "" + seats;
            if (vehiclePark.contains(requested)) {
                countSold++;
                int price = currentVehicle.charAt(0) * seats;
                System.out.printf("Yes, sold for %d$\n", price);
                vehiclePark.remove(requested);

            } else {
                System.out.println("No");
            }

            request = scanner.nextLine();
        }

        System.out.printf("Vehicles left: %s\n", String.join(", ", vehiclePark));
        System.out.printf("Vehicles sold: %d\n", countSold);
    }
}
