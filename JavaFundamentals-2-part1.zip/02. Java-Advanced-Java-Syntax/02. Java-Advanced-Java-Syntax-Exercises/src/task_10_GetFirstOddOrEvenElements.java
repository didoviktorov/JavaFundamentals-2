import java.util.Scanner;

public class task_10_GetFirstOddOrEvenElements {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String[] nums = scanner.nextLine().split("\\s+");
        int[] numbers = new int[nums.length];
        for (int i = 0; i < numbers.length; i++) {
            numbers[i] = Integer.parseInt(nums[i]);
        }

        String[] commands = scanner.nextLine().split("\\s+");
        int quantity = Integer.parseInt(commands[1]);
        String type = commands[2];
        String result = "";

        System.out.println(getNumbers(quantity, type, numbers));
    }

    public static String getNumbers (int quantity, String type, int[] numbers){
        String result = "";
        int counter = 0;
        for (int i = 0; i < numbers.length; i++) {
            if (type.equals("even") && counter < quantity && numbers[i] % 2 == 0) {
                result += numbers[i] + " ";
                counter++;
            } else if (type.equals("odd") && counter < quantity && numbers[i] % 2 != 0) {
                result += numbers[i] + " ";
                counter++;
            }

        }

        return result.trim();
    }
}
