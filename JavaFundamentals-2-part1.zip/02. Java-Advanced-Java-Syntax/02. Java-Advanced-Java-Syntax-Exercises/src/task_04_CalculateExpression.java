import java.util.Locale;
import java.util.Scanner;

public class task_04_CalculateExpression {
    public static void main(String[] args) {
        Locale.setDefault(Locale.ROOT);
        Scanner scanner = new Scanner(System.in);

        double a = scanner.nextDouble();
        double b = scanner.nextDouble();
        double c = scanner.nextDouble();

        double exp = ((Math.pow(a, 2) + Math.pow(b, 2)) / (Math.pow(a, 2) - Math.pow(b, 2)));
        double firstResult = Math.pow(exp, (a + b + c) / Math.sqrt(c));

        double secondResult = Math.pow((Math.pow(a, 2) + Math.pow(b, 2) - Math.pow(c, 3)), a - b);

        double diff = Math.abs(((a + b + c) / 3) - ((firstResult + secondResult) / 2));

        System.out.printf("F1 result: %.2f; F2 result: %.2f; Diff: %.2f", firstResult, secondResult, diff);
    }
}
