import java.util.Locale;
import java.util.Scanner;

public class task_03_FormattingNumbers {
    public static void main(String[] args) {
        Locale.setDefault(Locale.ROOT);
        Scanner scanner = new Scanner(System.in);
        int a = scanner.nextInt();
        double b = scanner.nextDouble();
        double c = scanner.nextDouble();

        String hex = String.format("%-10s" , Integer.toHexString(a).toUpperCase());
        String binary = String.format("%10s", Integer.toBinaryString(a)).replace(' ', '0');
        String twoDecimals = String.format("%10s", String.format("%.2f", b));
        String threeDecimals = String.format("%-10s", String.format("%.3f", c));

        System.out.printf("|%s|%s|%s|%s|", hex, binary, twoDecimals, threeDecimals);
    }
}
