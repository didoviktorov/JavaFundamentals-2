import java.util.Scanner;

public class task_06_BaseSevenToDecimal {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int number = Integer.parseInt(scanner.nextLine());
        System.out.println(convertToDecimalBase(number));
    }

    public static long convertToDecimalBase (int num) {
        long convertedNumber = 0;
        String numToConvert = num + "";
        for (int i = 0; i < numToConvert.length(); i++) {
            int currNum = Integer.parseInt(numToConvert.charAt(i) + "");
            convertedNumber += (currNum * Math.pow(7, numToConvert.length() - 1 - i));
        }

        return convertedNumber;
    }
}
