import java.util.Scanner;

public class greeting_04 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        String name = scanner.nextLine();
        String lastName = scanner.nextLine();

        if (name.isEmpty()) {
            name = "*****";
        }

        if (lastName.isEmpty()) {
            lastName = "*****";
        }

        System.out.println("Hello, " + name + " " + lastName + "!");
    }
}
