public class numbers_06 {
    public static void main(String[] args) {
        int number = 0;

        while (number < 10) {
            System.out.println("Number: " + number);
            number++;
        }
    }
}
