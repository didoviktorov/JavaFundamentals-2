import java.util.Scanner;

public class transportPrice_05 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        double distance = Double.parseDouble(scanner.nextLine());
        String dayTime = scanner.nextLine();

        double result;
        if(distance < 20) {
            if (dayTime.equals("night")) {
                result = (distance * 0.9) + 0.7;
            } else {
                result = (distance * 0.79) + 0.7;
            }
        } else if (distance >= 20 && distance < 100) {
            result = distance * 0.09;
        } else {
            result = distance * 0.06;
        }

        System.out.printf("%.2f", result);
    }
}
