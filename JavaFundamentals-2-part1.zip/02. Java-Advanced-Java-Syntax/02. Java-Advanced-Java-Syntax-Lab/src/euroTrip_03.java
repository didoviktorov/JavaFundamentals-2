import java.math.BigDecimal;
import java.util.Locale;
import java.util.Scanner;

public class euroTrip_03 {
    public static void main(String[] args) {
        Locale.setDefault(Locale.ROOT);
        Scanner scanner = new Scanner(System.in);
        double quantity = Double.parseDouble(scanner.nextLine());
        double pricePerKilo = 1.20;

        BigDecimal priceBgn = new BigDecimal(quantity * pricePerKilo);
        BigDecimal rate = new BigDecimal("4210500000000");

        System.out.printf("%.2f marks", priceBgn.multiply(rate));
    }
}
