import java.util.Scanner;

public class ReadInput_01 {
    public static void main(String[] args) {
        Scanner scn = new Scanner(System.in);
        String firstWord = scn.next();
        String secondWord = scn.next();

        int firstNum = scn.nextInt();
        int secondNum = scn.nextInt();
        int thirdNum = scn.nextInt();
        scn.nextLine();
        String thirdWord = scn.next();

        System.out.println(firstWord + " " + secondWord + " " + thirdWord + " " + (firstNum + secondNum + thirdNum));
    }
}
