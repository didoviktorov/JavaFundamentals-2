import java.util.Locale;
import java.util.Scanner;

public class calculateTriangleArea_09 {
    public static void main(String[] args) {
        Locale.setDefault(Locale.ROOT);
        Scanner scanner = new Scanner(System.in);

        double base = scanner.nextDouble();
        double height = scanner.nextDouble();

        System.out.printf("Area = %.2f", calculateArea(base, height));

    }

    public static double calculateArea(double b, double h) {
        double result = (b * h) / 2;
        return result;
    };
}
