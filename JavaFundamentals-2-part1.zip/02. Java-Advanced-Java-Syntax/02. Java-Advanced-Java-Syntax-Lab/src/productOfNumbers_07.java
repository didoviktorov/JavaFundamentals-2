import java.math.BigInteger;
import java.util.Scanner;

public class productOfNumbers_07 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int firstNum = scanner.nextInt();
        int secondNum = scanner.nextInt();

        int start = firstNum;

        BigInteger result = BigInteger.ONE;
        do {
            result = result.multiply(BigInteger.valueOf(start));
            start++;
        } while (start <= secondNum);

        System.out.printf("product[%d..%d] = %d", firstNum, secondNum, result);
    }
}
