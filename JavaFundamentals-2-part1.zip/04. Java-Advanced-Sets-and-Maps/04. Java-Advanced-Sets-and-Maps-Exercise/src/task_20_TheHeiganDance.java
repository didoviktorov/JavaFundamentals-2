import java.util.Scanner;

public class task_20_TheHeiganDance {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        double playerHealth = 18500;
        double heiganHealth = 3000000;
        double cloudDamage = 3500;
        double eruptionDamage = 6000;
        int playerRow = 7;
        int playerCol = 7;

        double playerDamage = Double.parseDouble(scanner.nextLine());
        boolean hasCloud = false;
        String line = scanner.nextLine();
        while (true) {
            String[] params = line.split("\\s+");
            String attack = params[0];
            int row = Integer.parseInt(params[1]);
            int col = Integer.parseInt(params[2]);
            int minRow = row - 1;
            int maxRow = row + 1;
            if (minRow < 0) {
                minRow = 0;
            }
            if (maxRow > 14) {
                maxRow = 14;
            }
            int minCol = col - 1;
            int maxCol = col + 1;
            if (minCol < 0) {
                minCol = 0;
            }
            if (maxCol > 14) {
                maxCol = 14;
            }
            heiganHealth -= playerDamage;
            if (heiganHealth <= 0) {
                System.out.println("Heigan: Defeated!");
                if (hasCloud) {
                    playerHealth -= cloudDamage;
                }
                if (playerHealth > 0) {
                    System.out.println("Player: " + (int)playerHealth);
                } else {
                    System.out.println("Player: Killed by Plague Cloud");
                }
                System.out.println("Final position: " + playerRow + ", " + playerCol);
                break;
            }

            String attackStr = "";
            // If player is in range of the attack
            if (!isInRange(minRow, maxRow, minCol, maxCol, playerRow, playerCol)) {
                if (hasCloud) {
                    playerHealth -= cloudDamage;
                    hasCloud = false;
                }
            } else {
                boolean escaped = false;
                int newMinR = playerRow - 1;
                int newMaxC = playerCol + 1;
                int newMaxR = playerRow + 1;
                int newMinC = playerCol - 1;

                if (newMinR >= 0 && !isInRange(minRow, maxRow, minCol, maxCol, newMinR, playerCol)) {
                    playerRow = newMinR;
                    escaped = true;
                } else if (newMaxC < 15 && !isInRange(minRow, maxRow, minCol, maxCol, playerRow, newMaxC)) {
                    playerCol = newMaxC;
                    escaped = true;
                } else if (newMaxR < 15 && !isInRange(minRow, maxRow, minCol, maxCol, newMaxR, playerCol)) {
                    playerRow = newMaxR;
                    escaped = true;
                } else if (newMinC >= 0 && !isInRange(minRow, maxRow, minCol, maxCol, playerRow, newMinC)) {
                    playerCol = newMinC;
                    escaped = true;
                }


                if (!escaped) {
                    switch (attack) {
                        case "Cloud":
                            if (hasCloud) {
                                playerHealth -= cloudDamage;
                            }
                            playerHealth -= cloudDamage;
                            hasCloud = true;
                            if (playerHealth <= 0) {
                                attackStr = "Plague Cloud";
                            }
                            break;
                        case "Eruption":
                            if (hasCloud) {
                                playerHealth -= cloudDamage;
                                hasCloud = false;
                                if (playerHealth <= 0) {
                                    attackStr = "Plague Cloud";
                                    break;
                                }
                            }
                            playerHealth -= eruptionDamage;
                            if (playerHealth <= 0) {
                                attackStr = "Eruption";
                            }
                            break;
                    }
                }
            }
            if (playerHealth <= 0) {
                System.out.printf("Heigan: %.2f\n", heiganHealth);
                System.out.println("Player: Killed by " + attackStr);
                System.out.println("Final position: " + playerRow + ", " + playerCol);
                break;
            }
            line = scanner.nextLine();
        }
    }

    private static boolean isInRange(int minRow, int maxRow, int minCol, int maxCol, int playerRow, int playerCol) {
        return (playerRow >= minRow && playerRow <= maxRow && playerCol >= minCol && playerCol <= maxCol);
    }
}

