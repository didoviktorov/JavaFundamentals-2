import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Scanner;

public class task_19_Crossfire {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String[] dimensions = scanner.nextLine().split("\\s+");
        int rows = Integer.parseInt(dimensions[0]);
        int cols = Integer.parseInt(dimensions[1]);

        List<List<String>> matrix = new ArrayList<>();
        int number = 1;
        for (int i = 0; i < rows; i++) {
            List<String> currList = new ArrayList<>();
            for (int j = 0; j < cols; j++) {
                currList.add(number + "");
                number++;
            }
            matrix.add(currList);
        }

        String line = scanner.nextLine();
        while (!line.equals("Nuke it from orbit")) {
            String[] params = line.split("\\s+");
            Long bombRow = Long.parseLong(params[0]);
            int bombCol = Integer.parseInt(params[1]);
            Long radius = Long.parseLong(params[2]);

            rows = matrix.size();
            Long minBombRow = bombRow - radius;
            Long maxBombRow = bombRow + radius;
            Long minBombCol = bombCol - radius;
            Long maxBombCol = bombCol + radius;
            rows = matrix.size();
            for (int row = 0; row < rows; row++) {
                if (row != bombRow && row >= minBombRow && row <= maxBombRow) {
                    if (bombCol >= 0 && bombCol < matrix.get(row).size()) {
                        matrix.get(row).remove(bombCol);
                    }
                } else if (row == bombRow){
                    int currCols = matrix.get(row).size();
                    for (int col = currCols - 1; col >= 0; col--) {
                        if (col >= minBombCol && col <= maxBombCol) {
                            matrix.get(row).remove(col);
                        }
                    }
                }
            }

            List<List<String>> newMatrix = new ArrayList<>();
            for (int i = 0; i < rows; i++) {
                if (matrix.get(i).size() != 0) {
                    newMatrix.add(matrix.get(i));
                }
            }
            matrix.clear();
            matrix.addAll(newMatrix);
            line = scanner.nextLine();
        }

        for (List<String> row : matrix) {
            if (row.size() > 0) {
                System.out.println(String.join(" ", row));
            }

        }
    }
}
