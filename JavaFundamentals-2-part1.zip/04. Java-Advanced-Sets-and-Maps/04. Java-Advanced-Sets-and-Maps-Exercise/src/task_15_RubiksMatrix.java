import java.util.ArrayDeque;
import java.util.Deque;
import java.util.Scanner;

public class task_15_RubiksMatrix {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        String[] dimensions = scanner.nextLine().trim().split("\\s+");
        int rows = Integer.parseInt(dimensions[0]);
        int cols = Integer.parseInt(dimensions[1]);
        int number = 1;
        String[][] cube = new String[rows][cols];
        for (int row = 0; row < rows; row++) {
            for (int col = 0; col < cols; col++) {
                cube[row][col] = number + "";
                number++;
            }

        }

        int numberOfLines = Integer.parseInt(scanner.nextLine());
        for (int l = 0; l < numberOfLines; l++) {
            String[] line = scanner.nextLine().split("\\s+");
            String command = line[1];
            int rc = Integer.parseInt(line[0]);
            int moves = Integer.parseInt(line[2]);
            switch (command) {
                case "up":
                    cube = moveUpDown(cube, rc, moves, command);
                    break;
                case "down":
                    cube = moveUpDown(cube, rc, moves, command);
                    break;
            }
        }
    }

    private static String[][] moveUpDown (String[][] matrix, int col, int moves, String cmd) {
        int rows = matrix.length;
        Deque<String> column = new ArrayDeque<>();
        for (int r = 0; r < rows; r++) {
            column.offer(matrix[r][col]);
        }
        if (moves >= column.size()) {
            moves %= column.size();
        }
        if (cmd.equals("up")) {
            for (int m = 0; m < moves; m++) {
                column.offer(column.poll());
            }
        } else {
            for (int m = 0; m < moves; m++) {
                column.push(column.pop());
            }
        }

        for (int r = 0; r < rows; r++) {
            matrix[r][col] = column.poll();
        }
        return matrix;
    }
}
