import java.util.ArrayList;
import java.util.Scanner;

public class task_17_LegoBlocks {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int lines = Integer.parseInt(scanner.nextLine());
        String[][] first = new String[lines][];
        String[][] second = new String[lines][];
        int numberCells = 0;
        for (int line = 0; line < lines; line++) {
            first[line] = scanner.nextLine().trim().split("\\s+");
            numberCells += first[line].length;
        }
        for (int line = 0; line < lines; line++) {
            second[line] = scanner.nextLine().trim().split("\\s+");
            numberCells += second[line].length;
        }

        int fitSize = first[0].length + second[0].length;
        boolean hasFit = true;
        for (int i = 0; i < lines; i++){
            if (first[i].length + second[i].length != fitSize) {
                hasFit = false;
                break;
            }
        }

        if(!hasFit) {
            System.out.println("The total number of cells is: " + numberCells);
        } else {
            for (int i = 0; i < second.length; i++) {
                ArrayList<String> resultRow = new ArrayList<>();
                for (int j = 0; j < first[i].length; j++) {
                    resultRow.add(first[i][j]);
                }
                for (int j = second[i].length - 1; j >= 0; j--) {
                    resultRow.add(second[i][j]);
                }
                System.out.println("[" + String.join(", ", resultRow) + "]");
            }
        }
    }
}
