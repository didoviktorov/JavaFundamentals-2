import java.util.Scanner;

public class task_16_TargetPractice {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String[] dimensions = scanner.nextLine().trim().split("\\s+");
        int rows = Integer.parseInt(dimensions[0]);
        int cols = Integer.parseInt(dimensions[1]);
        String[][] stairs = new String[rows][cols];
        String snake = scanner.nextLine();
        String[] shotDimensions = scanner.nextLine().trim().split("\\s+");

        int indexChar = 0;
        int startFillRow = 0;
        for (int row = rows - 1; row >= 0; row--) {
            if (startFillRow % 2 == 0) {
                for (int col = cols - 1; col >= 0; col--) {
                    stairs[row][col] = snake.charAt(indexChar % snake.length()) + "";
                    indexChar++;
                }
            } else {
                for (int col = 0; col < cols; col++) {
                    stairs[row][col] = snake.charAt(indexChar % snake.length()) + "";
                    indexChar++;
                }
            }
            startFillRow++;
        }

        int bombX = Integer.parseInt(shotDimensions[0]);
        int bombY = Integer.parseInt(shotDimensions[1]);
        int bombRadius = Integer.parseInt(shotDimensions[2]);
        for (int row = 0; row < rows; row++) {
            for (int col = 0; col < cols; col++) {
                double x = Math.pow(row - bombX, 2);
                double y = Math.pow(col - bombY, 2);
                double distance = Math.sqrt(x + y);
                if (distance <= bombRadius) {
                    stairs[row][col] = " ";
                }
            }
        }

        for (int col = 0; col < cols; col++) {
            StringBuilder sb = new StringBuilder();
            boolean hasWhiteSpace = false;
            for (int row = 0; row < rows; row++) {
                sb.append(stairs[row][col]);
                if (stairs[row][col].equals(" ")) {
                    hasWhiteSpace = true;
                }
            }
            if (hasWhiteSpace) {
                String line = sb.toString();
                int startIndex = line.indexOf(" ");
                int endIndex = line.lastIndexOf(" ") + 1;
                int length = endIndex - startIndex;
                String newLine =
                        String.format("%" + length + "s", " ") + line.substring(0, startIndex) + line.substring(endIndex);

                for (int row = 0; row < rows; row++) {
                    stairs[row][col] = newLine.charAt(row) + "";
                }
            }
        }

        for (int r = 0; r < rows; r++) {

            for (int c = 0; c < cols; c++) {
                System.out.print(stairs[r][c]);
            }
            System.out.println();
        }
    }
}
