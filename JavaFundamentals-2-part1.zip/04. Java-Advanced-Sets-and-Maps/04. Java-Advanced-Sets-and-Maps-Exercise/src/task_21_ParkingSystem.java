import java.util.Scanner;

public class task_21_ParkingSystem {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String[] dimensions = scanner.nextLine().split("\\s+");
        int rows = Integer.parseInt(dimensions[0]);
        int cols = Integer.parseInt(dimensions[1]);
        boolean[][] parking = new boolean[rows][cols];
        for (int row = 0; row < rows; row++) {
            for (int col = 1; col < cols; col++) {
                parking[row][col] = true;
            }
        }

        String line = scanner.nextLine();
        while (!line.equals("stop")) {
            String[] params = line.split("\\s+");
            int startRow = Integer.parseInt(params[0]);
            int desiredRow = Integer.parseInt(params[1]);
            int desiredCol = Integer.parseInt(params[2]);
            if (isRowFull(parking, desiredRow)) {
                System.out.println("Row " + desiredRow + " full");
            } else {
                int pathToPark = 1 + Math.abs(desiredRow - startRow) + desiredCol;
                if (parking[desiredRow][desiredCol]) {
                    parking[desiredRow][desiredCol] = false;
                    System.out.println(pathToPark);
                } else {
                    int rightDistance = 0;
                    int rightCol = 0;
                    int leftDistance = 0;
                    int leftCol = 0;
                    boolean parkedLeft = false;
                    boolean parkedRight = false;
                    for (int col = desiredCol - 1; col > 0; col--) {
                        leftDistance++;
                        if (parking[desiredRow][col]) {
                            leftCol = col;
                            parkedLeft = true;
                            break;
                        }
                    }
                    for (int col = desiredCol + 1; col < parking[desiredRow].length; col++) {
                        rightDistance++;
                        if (parking[desiredRow][col]) {
                            parkedRight = true;
                            rightCol = col;
                            break;
                        }
                    }
                    if (leftDistance <= rightDistance && parkedLeft) {
                        pathToPark -= leftDistance;
                        parking[desiredRow][leftCol] = false;
                    } else {
                        if (parkedRight) {
                            pathToPark += rightDistance;
                            parking[desiredRow][rightCol] = false;
                        } else {
                            pathToPark -= leftDistance;
                            parking[desiredRow][leftCol] = false;
                        }

                    }
                    System.out.println(pathToPark);
                }
            }
            line = scanner.nextLine();
        }
    }

    private static boolean isRowFull (boolean[][] matrix, int row) {
        boolean result = true;
        for (int col = 1; col < matrix[row].length; col++) {
            if (matrix[row][col] == true) {
                result = false;
                break;
            }
        }
        return result;
    }
}
