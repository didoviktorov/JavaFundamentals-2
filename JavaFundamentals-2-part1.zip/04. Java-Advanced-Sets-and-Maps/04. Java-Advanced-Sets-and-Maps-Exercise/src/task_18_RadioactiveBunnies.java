import java.util.Scanner;

public class task_18_RadioactiveBunnies {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String[] dimensions = scanner.nextLine().split("\\s+");
        int rows = Integer.parseInt(dimensions[0]);
        int cols = Integer.parseInt(dimensions[1]);
        char[][] field = new char[rows][cols];
        int playerRow = -1;
        int playerCol = -1;
        for (int row = 0; row < rows; row++) {
            char[] rowToFill = scanner.nextLine().toCharArray();
            for (int col = 0; col < rowToFill.length; col++) {
                char symbol = rowToFill[col];
                field[row][col] = symbol;
                if (symbol == 'P') {
                    playerRow = row;
                    playerCol = col;
                }
            }
        }
        char[] moves = scanner.nextLine().toCharArray();
        for (int move = 0; move < moves.length; move++) {
            char c = moves[move];
            boolean hasEscaped = false;
            boolean died = false;
            switch (c) {
                case 'U':
                    if (playerRow == 0) {
                        hasEscaped = true;
                        field[playerRow][playerCol] = '.';
                    } else if (field[playerRow - 1][playerCol] == 'B') {
                        died = true;
                        playerRow -= 1;
                    } else {
                        field[playerRow - 1][playerCol] = 'P';
                        field[playerRow][playerCol] = '.';
                        playerRow -= 1;
                    }
                    break;
                case 'L':
                    if (playerCol == 0) {
                        hasEscaped = true;
                        field[playerRow][playerCol] = '.';
                    } else if (field[playerRow][playerCol - 1] == 'B') {
                        died = true;
                        playerCol -= 1;
                    } else {
                        field[playerRow][playerCol - 1] = 'P';
                        field[playerRow][playerCol] = '.';
                        playerCol -= 1;
                    }
                    break;
                case 'R':
                    if (playerCol == field[playerRow].length - 1) {
                        hasEscaped = true;
                        field[playerRow][playerCol] = '.';
                    } else if (field[playerRow][playerCol + 1] == 'B') {
                        died = true;
                        playerCol += 1;
                    } else {
                        field[playerRow][playerCol + 1] = 'P';
                        field[playerRow][playerCol] = '.';
                        playerCol += 1;
                    }
                    break;
                case 'D':
                    if (playerRow == field.length - 1) {
                        hasEscaped = true;
                        field[playerRow][playerCol] = '.';
                    } else if (field[playerRow + 1][playerCol] == 'B') {
                        died = true;
                        playerRow += 1;
                    } else {
                        field[playerRow + 1][playerCol] = 'P';
                        field[playerRow][playerCol] = '.';
                        playerRow += 1;
                    }
                    break;
            }

            if (hasEscaped) {
                field = spreadBunnies(field);
                printMatrix(field, rows, cols);
                System.out.println("won: " + playerRow +  " " + playerCol);
                break;
            } else if (died) {
                field = spreadBunnies(field);
                printMatrix(field, rows, cols);
                System.out.println("dead: " + playerRow + " " +  playerCol);
                break;
            } else {
                field = spreadBunnies(field);
                if (field[playerRow][playerCol] == 'B') {
                    printMatrix(field, rows, cols);
                    System.out.println("dead: " + playerRow + " " + playerCol);
                    break;
                }
            }
        }

    }

    private static void printMatrix (char[][] matrix, int rows, int cols) {
        for (int row = 0; row < rows; row++) {
            for (int col = 0; col < cols; col++) {
                System.out.print(matrix[row][col]);
            }
            System.out.println();
        }
    }

    private static char[][] spreadBunnies (char[][] matrix) {
        char[][] result = new char[matrix.length][matrix[0].length];
        for (int row = 0; row < matrix.length; row++) {
            for (int col = 0; col < matrix[0].length; col++) {
                char symbol = matrix[row][col];
                result[row][col] = matrix[row][col];
            }

        }
        for (int row = 0; row < matrix.length; row++) {
            for (int col = 0; col < matrix[row].length; col++) {
                char symbol = matrix[row][col];
                if (symbol == 'B') {
                    if (row > 0 && row < matrix.length - 1 && col > 0 && col < matrix[row].length - 1) {
                        result[row - 1][col] = 'B';
                        result[row][col - 1] = 'B';
                        result[row][col + 1] = 'B';
                        result[row + 1][col] = 'B';
                    } else if (row == 0 && col == 0) {
                        result[row + 1][col] = 'B';
                        result[row][col + 1] = 'B';
                    } else if (row == matrix.length - 1 && col == 0) {
                        result[row][col + 1] = 'B';
                        result[row - 1][col] = 'B';
                    } else if (row == 0 && col == matrix[row].length - 1) {
                        result[row][col - 1] = 'B';
                        result[row + 1][col] = 'B';
                    } else if (row == matrix.length - 1 && col == matrix[row].length - 1) {
                        result[row][col - 1] = 'B';
                        result[row - 1][col] = 'B';
                    } else if (row == 0 && col > 0 && col < matrix[row].length - 1) {
                        result[row][col - 1] = 'B';
                        result[row][col + 1] = 'B';
                        result[row + 1][col] = 'B';
                    } else if (row > 0 && row < matrix.length - 1 && col == 0) {
                        result[row - 1][col] = 'B';
                        result[row + 1][col] = 'B';
                        result[row][col + 1] = 'B';
                    } else if (row == matrix.length - 1 && col > 0 && col < matrix[row].length - 1) {
                        result[row][col - 1] = 'B';
                        result[row][col + 1] = 'B';
                        result[row - 1][col] = 'B';
                    } else if (col == matrix[row].length - 1 && row > 0 && row < matrix.length - 1) {
                        result[row - 1][col] = 'B';
                        result[row + 1][col] = 'B';
                        result[row][col - 1] = 'B';
                    }
                }
            }
        }
        return result;
    }
}
