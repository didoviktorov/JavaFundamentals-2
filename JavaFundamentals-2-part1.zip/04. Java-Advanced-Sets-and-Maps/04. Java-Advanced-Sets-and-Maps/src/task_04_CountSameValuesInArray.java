import java.util.*;

public class task_04_CountSameValuesInArray {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String[] values = scanner.nextLine().split("\\s+");
        HashMap<String, Integer> numbers = new HashMap<>();
        for (int i = 0; i < values.length; i++) {
            String currentNumber = values[i];
            if (!numbers.containsKey(currentNumber)) {
                numbers.put(currentNumber, 1);
            } else {
                numbers.put(currentNumber, numbers.get(currentNumber) + 1);
            }
        }

        for (String key : numbers.keySet()) {
            System.out.printf("%s - %d times\n", key, numbers.get(key));
        }
    }
}
