import java.util.Arrays;
import java.util.LinkedHashSet;
import java.util.Scanner;

public class task_03_VoinaNumberGame {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        LinkedHashSet<String> firstPlayer = new LinkedHashSet<>();
        LinkedHashSet<String> secondPlayer = new LinkedHashSet<>();

        firstPlayer.addAll(Arrays.asList(scanner.nextLine().split("\\s")));
        secondPlayer.addAll(Arrays.asList(scanner.nextLine().split("\\s")));

        int rounds = 50;
        boolean hasWinner = false;
        for (int i = 0; i < rounds; i++) {
            int first = Integer.parseInt(firstPlayer.iterator().next());
            firstPlayer.remove(first + "");
            int second = Integer.parseInt(secondPlayer.iterator().next());
            secondPlayer.remove(second + "");
            if (first > second) {
                firstPlayer.add(first + "");
                firstPlayer.add(second + "");
            } else if (second > first){
                secondPlayer.add(first + "");
                secondPlayer.add(second + "");
            }
            if (firstPlayer.size() <= 0 || secondPlayer.size() <= 0) {
                break;
            }
        }
        if (hasWinner == false) {
            if (firstPlayer.size() == secondPlayer.size()) {
                System.out.println("Draw!");
            }
            else if (firstPlayer.size() > secondPlayer.size()) {
                System.out.println("First player win!");
            } else {
               System.out.println("Second player win!");
            }
        }
    }
}