import java.util.Scanner;
import java.util.TreeMap;

public class task_05_AcademyGraduation {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int numberOfStudents = Integer.parseInt(scanner.nextLine());
        TreeMap<String, Double> students = new TreeMap<>();
        for (int student = 0; student < numberOfStudents; student++) {
            String name = scanner.nextLine();
            String[] grades = scanner.nextLine().split("\\s+");
            double sum = 0;
            for (int i = 0; i < grades.length; i++) {
                sum += Double.parseDouble(grades[i]);
            }
            students.put(name, sum / grades.length);
        }

        for (String student : students.keySet()) {
            System.out.println(student + " is graduated with " + students.get(student));
        }
    }
}
