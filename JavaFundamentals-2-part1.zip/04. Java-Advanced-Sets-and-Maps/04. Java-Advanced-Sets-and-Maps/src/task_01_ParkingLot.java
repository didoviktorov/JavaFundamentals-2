import java.util.HashSet;
import java.util.Scanner;

public class task_01_ParkingLot {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        HashSet<String> parking = new HashSet<>();
        String command = scanner.nextLine();
        while (!command.equals("END")) {
            String[] params = command.split(",\\s+");
            String action = params[0];
            if (action.equals("IN")) {
                parking.add(params[1]);
            } else {
                parking.remove(params[1]);
            }
            command = scanner.nextLine();
        }
        if (parking.isEmpty()) {
            System.out.println("Parking Lot is Empty");
        } else {
            System.out.println(String.join("\n", parking));
        }
    }
}
