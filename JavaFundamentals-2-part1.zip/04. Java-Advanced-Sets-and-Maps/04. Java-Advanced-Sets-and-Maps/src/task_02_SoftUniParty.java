import java.util.Scanner;
import java.util.TreeSet;

public class task_02_SoftUniParty {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        TreeSet<String> guestList = new TreeSet<>();
        String line = scanner.nextLine();
        while (!line.equals("PARTY")) {
            guestList.add(line);
            line = scanner.nextLine();
        }
        while (!line.equals("END")) {
            guestList.remove(line);
            line = scanner.nextLine();
        }
        System.out.println(guestList.size());
        System.out.println(String.join("\n", guestList));
    }
}
