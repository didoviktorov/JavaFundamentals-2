import java.io.IOException;

public class Program {
    public static void main(String[] args) throws IOException {
//        StudentsRepository.initializeData();
//        StudentsRepository.getStudentsByCourse("Unity");

//        String test1Path = "E:\\software\\JavaFundamentals-2\\04. Java-Advanced-Sets-and-Maps\\BashSoft\\test1.txt";
//        String test2Path = "E:\\software\\JavaFundamentals-2\\04. Java-Advanced-Sets-and-Maps\\BashSoft\\test2.txt";
//        String test3Path = "E:\\software\\JavaFundamentals-2\\04. Java-Advanced-Sets-and-Maps\\BashSoft\\test3.txt";
//        Tester.compareContent(test1Path, test2Path);
//        Tester.compareContent(test1Path, test3Path);

//        IOManager.createDirectoryInCurrentFolder("Pesho");
        InputReader.readCommands();
    }
}
