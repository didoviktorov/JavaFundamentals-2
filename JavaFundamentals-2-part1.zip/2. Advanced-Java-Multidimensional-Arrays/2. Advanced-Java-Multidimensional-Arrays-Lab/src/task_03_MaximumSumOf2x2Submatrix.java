import java.util.Scanner;

public class task_03_MaximumSumOf2x2Submatrix {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String[] dimensions = scanner.nextLine().split(", ");
        int rows = Integer.parseInt(dimensions[0]);
        int cols = Integer.parseInt(dimensions[1]);
        String[][] matrix = new String[rows][cols];
        for (int row = 0; row < rows; row++) {
            String[] currRow = scanner.nextLine().split(", ");
            for (int col = 0; col < cols; col++) {
                matrix[row][col] = currRow[col];
            }
        }
        long maxSum = Long.MIN_VALUE;
        String[][] maxSumMatrix = new String[2][2];
        for (int row = 0; row < rows - 1; row++) {
            for (int col = 0; col < cols - 1; col++) {
                long cell1 = Long.parseLong(matrix[row][col]);
                long cell2 = Long.parseLong(matrix[row][col + 1]);
                long cell3 = Long.parseLong(matrix[row + 1][col]);
                long cell4 = Long.parseLong(matrix[row + 1][col + 1]);
                Long currentSum = cell1 + cell2 + cell3 + cell4;
                if (currentSum > maxSum) {
                    maxSum = currentSum;
                    maxSumMatrix[0][0] = cell1 + "";
                    maxSumMatrix[0][1] = cell2 + "";
                    maxSumMatrix[1][0] = cell3 + "";
                    maxSumMatrix[1][1] = cell4 + "";
                }
            }
        }

        for (String[] row : maxSumMatrix) {
            System.out.println(String.join(" ", row));
        }
        System.out.println(maxSum);
    }
}
