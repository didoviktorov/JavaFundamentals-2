import java.util.Scanner;

public class task_02_SumMatrixElements {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String[] dimensions = scanner.nextLine().split(", ");
        int rows = Integer.parseInt(dimensions[0]);
        int cols = Integer.parseInt(dimensions[1]);
        String[][] matrix = new String[rows][cols];

        long sum = 0;
        for (String[] strings : matrix) {
            strings = scanner.nextLine().split(", ");
            for (String string : strings) {
                sum += Long.parseLong(string);
            }
        }
        System.out.printf("%d\n%d\n%d\n", rows, cols, sum);
    }
}
