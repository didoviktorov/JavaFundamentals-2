import java.util.Scanner;

public class task_04_GroupNumbers {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String[] row = scanner.nextLine().split(", ");
        String zeroReminder = "";
        String oneReminder = "";
        String twoReminder = "";
        for (String element : row) {
            if (Integer.parseInt(element) % 3 == 0) {
                zeroReminder += element + " ";
            } else if (Math.abs(Integer.parseInt(element) % 3) == 1) {
                oneReminder += element + " ";
            } else if (Math.abs(Integer.parseInt(element)) % 3 == 2) {
                twoReminder += element + " ";
            }
        }

        System.out.printf("%s\n%s\n%s\n", zeroReminder.trim(), oneReminder.trim(), twoReminder.trim());
    }
}
