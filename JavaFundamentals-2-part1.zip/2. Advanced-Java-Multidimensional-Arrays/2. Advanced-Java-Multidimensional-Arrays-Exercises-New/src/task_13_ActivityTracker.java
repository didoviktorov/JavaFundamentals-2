import java.util.*;

public class task_13_ActivityTracker {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        int lines = Integer.parseInt(scanner.nextLine());

        // First way
        //TreeMap<Integer, TreeMap<String, Integer>> data = new TreeMap<>();

        // Second way
        Map<Integer, TreeMap<String, Integer>> data = new TreeMap<>(
                // Passing into constructor for ascending order
                // Default way
                //new Comparator<Integer>() {
                //@Override
                //  public int compare(Integer o1, Integer o2) {
                //      return o1.compareTo(o2);
                //     }
                // }

                // Lambda way
                // Ascending order
                //(o1, o2) -> o1.compareTo(o2)
                // Descending order
                //(o1, o2) -> o2.compareTo(o1)

                // Method reference way
                Integer::compareTo
        );
        while (lines > 0) {
            String[] currentLine = scanner.nextLine().split("\\s+");
            int month = Integer.parseInt(currentLine[0].split("/")[1]);
            String name = currentLine[1];
            int distance = Integer.parseInt(currentLine[2]);
            if (!data.containsKey(month)) {
                data.put(month, new TreeMap<>());
                data.get(month).put(name, distance);
            } else if (!data.get(month).containsKey(name)) {
                data.get(month).put(name, distance);
            } else {
                data.get(month).put(name,  data.get(month).get(name) + distance);
            }
            lines--;
        }
// Third way (but using to much memory
//        LinkedHashMap<Integer, TreeMap<String, Integer>> sorted =
//                data.entrySet().stream().sorted((a, b) -> a.getKey().compareTo(b.getKey()))
//                .collect(Collectors.toMap(
//                        Map.Entry::getKey,
//                        Map.Entry::getValue,
//                        (x, y) -> {
//                            throw new AssertionError();
//                        },
//                        LinkedHashMap::new
//                ));

        for (Map.Entry<Integer, TreeMap<String, Integer>> entry : data.entrySet()) {
            List<String> values = new ArrayList<>();
            for (Map.Entry value : data.get(entry.getKey()).entrySet()) {
                values.add(String.format("%s(%d)", value.getKey(), value.getValue()));
            }

            System.out.printf("%d: %s%n", entry.getKey(), String.join(", ", values));
        }
    }
}
