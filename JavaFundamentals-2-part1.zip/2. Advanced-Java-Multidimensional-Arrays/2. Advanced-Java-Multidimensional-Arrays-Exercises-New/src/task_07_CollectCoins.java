import java.util.Scanner;

public class task_07_CollectCoins {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int rows = 4;
        char[][] matrix = new char[rows][];
        for (int row = 0; row < rows; row++) {
            matrix[row] = scanner.nextLine().toCharArray();
        }
        char[]moves = scanner.nextLine().toCharArray();
        int positionRow = 0;
        int positionCol = 0;
        int coins = 0;
        int hits = 0;
        for (int move = 0; move < moves.length; move++) {
            char direction = moves[move];
            switch (direction) {
                case 'V':
                    positionRow++;
                    if (positionRow < rows && positionCol < matrix[positionRow].length) {
                        if (matrix[positionRow][positionCol] == '$') {
                            coins++;
                        }
                    } else {
                        positionRow--;
                        hits++;
                    }
                    break;
                case '^':
                    positionRow--;
                    if (positionRow >= 0 && positionCol < matrix[positionRow].length) {
                        if (matrix[positionRow][positionCol] == '$') {
                            coins++;
                        }
                    } else {
                        positionRow++;
                        hits++;
                    }
                    break;
                case '>':
                    positionCol++;
                    if (positionCol < matrix[positionRow].length) {
                        if (matrix[positionRow][positionCol] == '$') {
                            coins++;
                        }
                    } else {
                        positionCol--;
                        hits++;
                    }
                    break;
                case '<':
                    positionCol--;
                    if (positionCol >= 0) {
                        if (matrix[positionRow][positionCol] == '$') {
                            coins++;
                        }
                    } else {
                        positionCol++;
                        hits++;
                    }
                    break;
            }
        }

        System.out.printf("Coins = %d\nWalls = %d\n", coins, hits);
    }
}
