import java.util.ArrayList;
import java.util.Scanner;

public class task_11_StringMatrixRotation {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String deg = scanner.nextLine();
        int degrees = Integer.parseInt(deg.substring(deg.indexOf('(') + 1, deg.indexOf(')'))) % 360;

        String line = scanner.nextLine();
        int maxLength = 0;
        int rows = 1;
        ArrayList<String> lines = new ArrayList<>();
        while (!line.equals("END")) {
            if (line.length() > maxLength) {
                maxLength = line.length();
            }
            lines.add(line);
            line = scanner.nextLine();
            if (!line.equals("END")) {
                rows++;
            }
        }

        // Fill the matrix for first time
        char[][] matrix = new char[lines.size()][maxLength];
        for (int row = 0; row < matrix.length; row++) {
            matrix[row] = String.format("%-" + maxLength + "s", lines.get(row)).toCharArray();
        }

        switch (degrees) {
            case 90:
                matrix = rotateRight(matrix, rows, maxLength);
                break;
            case 180:
                matrix = rotateDown(matrix, rows, maxLength);
                break;
            case 270:
                matrix = rotateLeft(matrix, rows, maxLength);
                break;
            default:
                break;
        }

        for (int row = 0; row < matrix.length; row++) {
            for (int col = 0; col < matrix[row].length; col++) {
                System.out.print(matrix[row][col]);
            }
            System.out.println();
        }
    }

    private static char[][] rotateRight (char[][] matrix, int rows, int cols) {
        char[][] resultMatrix = new char[cols][rows];
        for (int row = 0; row < resultMatrix.length; row++) {
            char[] currentRow = new char[rows];
            int currRow = rows - 1;
            for (int col = 0; col < rows; col++) {
                currentRow[col] = matrix[currRow][row];
                currRow--;
            }
            resultMatrix[row] = currentRow;
        }

        return resultMatrix;
    }

    private static char[][] rotateDown (char[][] matrix, int rows, int cols) {
        char[][] resultMatrix = new char[rows][cols];
        for (int row = 0; row < resultMatrix.length; row++) {
            char[] currentRow = new char[cols];
            int currentCol = cols - 1;
            int currRow = rows - row - 1;
            for (int col = 0; col < currentRow.length; col++) {
                currentRow[col] = matrix[currRow][currentCol];
                currentCol--;
            }
            resultMatrix[row] = currentRow;
        }

        return resultMatrix;
    }

    private static char[][] rotateLeft (char[][] matrix, int rows, int cols) {
        char[][] resultMatrix = new char[cols][rows];
        for (int row = 0; row < resultMatrix.length; row++) {
            char[] currentRow = new char[rows];
            int currCol = cols - row - 1;
            for (int col = 0; col < rows; col++) {
                currentRow[col] = matrix[col][currCol];
            }
            resultMatrix[row] = currentRow;
        }

        return resultMatrix;
    }
}
