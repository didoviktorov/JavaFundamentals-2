import java.util.Scanner;

public class task_02_MatrixOfPalindromes {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String[] dimensions = scanner.nextLine().split(" ");
        int rows = Integer.parseInt(dimensions[0]);
        int cols = Integer.parseInt(dimensions[1]);

        String[][] matrix = new String[rows][cols];
        int start = 97;
        for (int row = 0; row < rows; row++) {
            for (int col = 0; col < cols; col++) {
                String cell = "";
                cell += Character.toString((char) (start + row));
                cell += Character.toString((char) (start + row + col));
                cell += Character.toString((char) (start + row));
                matrix[row][col] = cell;
            }
        }

        for (int row = 0; row < rows; row++) {
            System.out.println(String.join(" ", matrix[row]));
        }
    }
}
