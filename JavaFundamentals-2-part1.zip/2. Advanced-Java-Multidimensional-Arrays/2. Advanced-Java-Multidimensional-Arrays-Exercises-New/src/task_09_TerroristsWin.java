import java.util.Scanner;

public class task_09_TerroristsWin {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String input = scanner.nextLine();

        int bombIndex = input.indexOf('|');
        while (bombIndex != -1) {
            int bombEnd = input.indexOf('|', bombIndex + 1);
            String bomb = input.substring(bombIndex + 1, bombEnd);
            int range = 0;
            for (Character c : bomb.toCharArray()) {
                range += c;
            }
            range %= 10;

            int startIndex = bombIndex - range;
            if (startIndex < 0) {
                startIndex = 0;
            }
            int endIndex = bombEnd + range;
            if (endIndex >= input.length()) {
                endIndex = input.length() - 1;
            }
            int replaceLength = endIndex - startIndex + 1;
            String replacement = new String(new char[replaceLength]).replace("\0", ".");
            input = input.substring(0, startIndex) + replacement + input.substring(endIndex + 1);
            bombIndex = input.indexOf('|', bombEnd + 1);
        }

        System.out.println(input);
    }
}
