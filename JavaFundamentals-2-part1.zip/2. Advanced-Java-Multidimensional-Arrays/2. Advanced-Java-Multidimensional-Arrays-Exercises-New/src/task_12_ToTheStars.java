import java.util.Scanner;

public class task_12_ToTheStars {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        String[] starOne = scanner.nextLine().split("\\s+");
        String starOneName = starOne[0];
        double starOneX = Double.parseDouble(starOne[1]);
        double starOneY = Double.parseDouble(starOne[2]);

        String[] starTwo = scanner.nextLine().split("\\s+");
        String starTwoName = starTwo[0];
        double starTwoX = Double.parseDouble(starTwo[1]);
        double starTwoY = Double.parseDouble(starTwo[2]);

        String[] starThree = scanner.nextLine().split("\\s+");
        String starThreeName = starThree[0];
        double starThreeX = Double.parseDouble(starThree[1]);
        double starThreeY = Double.parseDouble(starThree[2]);

        String[] normandy = scanner.nextLine().split("\\s+");
        double normandyX = Double.parseDouble(normandy[0]);
        double normandyY = Double.parseDouble(normandy[1]);

        double turns = Double.parseDouble(scanner.nextLine()) + 1;
        while (turns > 0) {
            if (checkOne(starOneX, starOneY, normandyX, normandyY)) {
                System.out.println(starOneName.toLowerCase());
            } else if (checkTwo(starTwoX, starTwoY, normandyX, normandyY)) {
                System.out.println(starTwoName.toLowerCase());
            } else if (checkThree(starThreeX, starThreeY, normandyX, normandyY)) {
                System.out.println(starThreeName.toLowerCase());
            } else {
                System.out.println("space");
            }
            normandyY++;
            turns--;
        }

    }

    private static boolean checkOne (double sX, double sY, double norX, double norY) {
        return norX <= sX + 1 && norX >= sX - 1 && norY <= sY + 1 && norY >= sY - 1;
    }

    private static boolean checkTwo (double sX, double sY, double norX, double norY) {
        return norX <= sX + 1 && norX >= sX - 1 && norY <= sY + 1 && norY >= sY - 1;
    }

    private static boolean checkThree (double sX, double sY, double norX, double norY) {
        return norX <= sX + 1 && norX >= sX - 1 && norY <= sY + 1 && norY >= sY - 1;
    }
}
