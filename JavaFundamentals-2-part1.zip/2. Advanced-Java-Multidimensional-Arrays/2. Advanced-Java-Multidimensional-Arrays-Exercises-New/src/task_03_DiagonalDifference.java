import java.util.Scanner;

public class task_03_DiagonalDifference {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int rows = Integer.parseInt(scanner.nextLine());
        String[][] matrix = new String[rows][];
        for (int i = 0; i < rows; i++) {
            matrix[i] = scanner.nextLine().split("\\s+");
        }

        long digonalASum = 0;
        long digonalBSum = 0;
        for (int i = 0; i < rows; i++) {
            digonalASum += Long.parseLong(matrix[i][i]);
            digonalBSum += Long.parseLong(matrix[i][rows - 1 - i]);
        }

        System.out.println(Math.abs(digonalASum - digonalBSum));
    }
}
