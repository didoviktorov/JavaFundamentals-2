import java.util.Scanner;

public class task_06_SequenceInMatrix {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String[] dimensions = scanner.nextLine().split(" ");
        int rows = Integer.parseInt(dimensions[0]);
        int cols = Integer.parseInt(dimensions[1]);
        String[][] matrix = new String[rows][cols];
        for (int row = 0; row < matrix.length; row++) {
            matrix[row] = scanner.nextLine().split("\\s+");
        }

        int maxSequence = 0;
        int maxRow = 0;
        int maxCol = 0;
        for (int row = 0; row < rows; row++) {
            for (int col = 0; col < cols; col++) {
                int cRow = row;
                int cCol = col;
                int currSequence = 1;

                // Check line
                while (cCol < cols - 1 && matrix[cRow][cCol].equals(matrix[cRow][cCol] + 1)) {
                    currSequence++;
                    if (currSequence > maxSequence) {
                        maxSequence = currSequence;
                        maxRow = cRow;
                        maxCol = cCol;
                    }
                    cCol++;
                }

                // Check column
                cCol = col;
                currSequence = 1;
                while (cRow < rows - 1 && matrix[cRow][cCol].equals(matrix[cRow + 1][cCol])) {
                    currSequence++;
                    if (currSequence >= maxSequence) {
                        maxSequence = currSequence;
                        maxRow = cRow;
                        maxCol = cCol;
                    }
                    cRow++;
                }

                // Check diagonal
                cRow = row;
                currSequence = 1;
                while (cRow < rows - 1 && cCol < cols - 1 && matrix[cRow][cCol].equals(matrix[cRow + 1][cCol + 1])) {
                    currSequence++;
                    if (currSequence > maxSequence) {
                        maxSequence = currSequence;
                        maxRow = cRow;
                        maxCol = cCol;
                    }
                    cRow++;
                    cCol++;
                }
            }
        }

        String repeatable = matrix[maxRow][maxCol];
        for (int i = 0; i < maxSequence; i++) {
            System.out.print(repeatable + ", ");
        }
    }
}