import java.util.ArrayDeque;
import java.util.Scanner;

public class task_05_HotPotato {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        ArrayDeque<String> queue = new ArrayDeque<>();
        String[] line = scanner.nextLine().split("\\s+");
        int turn = Integer.parseInt(scanner.nextLine());
        for (int i = 0; i < line.length; i++) {
            queue.offer(line[i]);
        }

        while (queue.size() > 1) {
            for (int i = 1; i < turn; i++) {
                queue.offer(queue.poll());
            }
            System.out.println("Removed " + queue.poll());
        }
        System.out.println("Last is " + queue.poll());
    }
}
