import java.util.ArrayDeque;
import java.util.Collections;
import java.util.Scanner;

public class task_06_MathPotato {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        ArrayDeque<String> queue = new ArrayDeque<>();
        Collections.addAll(queue, scanner.nextLine().split("\\s+"));
        int turn = Integer.parseInt(scanner.nextLine());

        int cycle = 1;
        while (queue.size() > 1) {
            for (int i = 1; i < turn; i++) {
                queue.offer(queue.poll());
            }

            if (isPrime(cycle)) {
                System.out.println("Prime  " + queue.peek());
            } else {
                System.out.println("Removed " + queue.poll());
            }
            cycle++;
        }

        System.out.println("Last is " + queue.poll());
    }

    private static boolean isPrime(int n) {
        for (int i = 2; i <= Math.sqrt(n); i++) {
            if (n % i == 0) {
                return false;
            }
        }
        if (n <= 1) {
            return false;
        }
        return true;
    }
}
