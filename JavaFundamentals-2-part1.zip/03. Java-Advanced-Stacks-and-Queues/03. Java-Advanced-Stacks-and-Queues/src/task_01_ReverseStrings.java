import java.util.ArrayDeque;
import java.util.Scanner;

public class task_01_ReverseStrings {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        ArrayDeque<Character> stack = new ArrayDeque<>();
        char[] line = scanner.nextLine().toCharArray();
        for (char c : line) {
            stack.push(c);
        }

        while (stack.size() > 0) {
            System.out.print(stack.pop());
        }
        System.out.println();
    }
}
