import java.util.ArrayDeque;
import java.util.Collections;
import java.util.Scanner;

public class task_07_PalindromeChecker {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        ArrayDeque<Character> queue = new ArrayDeque<>();
        String line = scanner.nextLine();
        for (int i = 0; i < line.length(); i++) {
            queue.offer(line.charAt(i));
        }
        if (isPalindrome(queue)) {
            System.out.println(true);
        } else {
            System.out.println(false);
        }
    }

    private static boolean isPalindrome (ArrayDeque<Character> q) {
        while (q.size() > 1) {
            char first = q.poll();
            char last = q.pollLast();
            if (first != last) {
                return false;
            }
        }
        return true;
    }
}
