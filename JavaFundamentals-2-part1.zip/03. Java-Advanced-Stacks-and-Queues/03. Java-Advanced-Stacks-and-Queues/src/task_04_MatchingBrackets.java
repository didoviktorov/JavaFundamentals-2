import java.util.ArrayDeque;
import java.util.Scanner;

public class task_04_MatchingBrackets {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String line = scanner.nextLine();

        ArrayDeque<Integer> indexes = new ArrayDeque<>();
        for (int index = 0; index < line.length(); index++) {
            if (line.charAt(index) == '(') {
                indexes.push(index);
            } else if (line.charAt(index) == ')') {
                int startIndex = indexes.pop();
                int endIndex = index + 1;
                System.out.println(line.substring(startIndex, endIndex));
            }

        }
    }
}
