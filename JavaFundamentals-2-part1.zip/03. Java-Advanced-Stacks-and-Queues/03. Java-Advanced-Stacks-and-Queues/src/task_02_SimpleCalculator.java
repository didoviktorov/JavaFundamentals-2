import java.util.ArrayDeque;
import java.util.Collections;
import java.util.Deque;
import java.util.Scanner;

public class task_02_SimpleCalculator {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        ArrayDeque<String> stack = new ArrayDeque<>();
        String[] elements = scanner.nextLine().split("\\s+");
        Collections.addAll(stack, elements);

        while (stack.size() > 1) {
            int first = Integer.valueOf(stack.pop());
            String op = stack.pop();
            int second = Integer.valueOf(stack.pop());

            switch (op) {
                case "+": stack.push(String.valueOf(first + second));
                    break;
                case "-": stack.push(String.valueOf(first - second));
                    break;
            }

        }

        System.out.println(stack.pop());
    }
}
