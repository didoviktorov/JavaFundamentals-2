package database;

import contracts.Repository;
import models.engines.BoatEngineImpl;
import models.boats.Boat;

public class BoatSimulatorDatabase {

    private static final BoatSimulatorDatabase INSTANCE = new BoatSimulatorDatabase();

    private Repository<Boat> boats;
    private Repository<BoatEngineImpl> engines;

    public BoatSimulatorDatabase() {
        this.boats = new RepositoryImpl<>();
        this.engines = new RepositoryImpl<>();
    }

    public static BoatSimulatorDatabase getInstance() {
        return INSTANCE;
    }

    public Repository<Boat> getBoats() {
        return this.boats;
    }

    public Repository<BoatEngineImpl> getEngines() {
        return this.engines;
    }
}
