package core;

import contracts.BoatEngine;
import contracts.BoatFactory;
import database.BoatSimulatorDatabase;
import exeptions.DuplicateModelException;
import exeptions.NonExistantModelException;
import models.boats.*;

public class BoatFactoryImpl implements BoatFactory {

    private BoatSimulatorDatabase database = BoatSimulatorDatabase.getInstance();

    public Boat createRowBoat(String model, int weight, int oars) throws DuplicateModelException {
        Boat boat = new RowBoat(model, weight, false, oars);
        return boat;
    }

    public Boat createSailBoat(String model, int weight, int sailEfficiency) throws DuplicateModelException {
        Boat boat = new SailBoat(model, weight, false, sailEfficiency);
        return boat;
    }

    public Boat createPowerBoat(String model, int weight, String firstEngineModel, String secondEngineModel) throws NonExistantModelException, DuplicateModelException {
        BoatEngine firstEngine = this.database.getEngines().getItem(firstEngineModel);
        BoatEngine secondEngine = this.database.getEngines().getItem(secondEngineModel);
        Boat boat = new PowerBoat(model, weight, true, firstEngine, secondEngine);
        return boat;
    }

    public Boat createYacht(String model, int weight, String engineModel, int cargoWeight) throws NonExistantModelException, DuplicateModelException {
        BoatEngine engine = this.database.getEngines().getItem(engineModel);
        Boat boat = new Yacht(model, weight, true, cargoWeight, engine);
        return boat;
    }
}
