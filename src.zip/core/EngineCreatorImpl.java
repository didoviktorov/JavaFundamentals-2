package core;

import contracts.BoatEngine;
import contracts.EngineCreator;
import database.BoatSimulatorDatabase;
import enumeration.EngineType;
import exeptions.DuplicateModelException;
import models.engines.BoatEngineImpl;
import models.engines.JetEngine;
import models.engines.SterndriveEngine;
import sun.reflect.generics.reflectiveObjects.NotImplementedException;
import utility.Constants;

public class EngineCreatorImpl implements EngineCreator {

    private BoatSimulatorDatabase database = BoatSimulatorDatabase.getInstance();

    public String createBoatEngine(String model, int horsepower, int displacement, EngineType engineType) throws DuplicateModelException {
        BoatEngineImpl engine;
        switch (engineType) {
            case JET:
                engine = new JetEngine(model, horsepower, displacement);
                break;
            case STERNDRIVE:
                engine = new SterndriveEngine(model, horsepower, displacement);
                break;
            default:
                throw new IllegalArgumentException(Constants.INCORRECT_ENGINE_TYPE_MESSAGE);
        }

        this.database.getEngines().add(engine);
        return "Engine model " + model + " with " + horsepower + " HP and displacement " + displacement + " cm3 created successfully.";
//        return String.format(
//            "Engine model %s with %s HP and displacement %s cm3 created successfully.",
//            model,
//            horsepower,
//            displacement);
    }
}
