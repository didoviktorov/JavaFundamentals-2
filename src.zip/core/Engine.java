package core;

import contracts.CommandHandler;
import contracts.Reader;
import contracts.Writer;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.*;

public class Engine {

    private CommandHandler commandHandler;
    private Writer writer;
    private Reader reader;

    public Engine(CommandHandler commandHandler, Reader reader, Writer writer) {
        this.commandHandler = commandHandler;
        this.reader = reader;
        this.writer = writer;
    }

    public void run() throws IOException {
        String line = this.reader.readLine();
        StringBuilder sb = new StringBuilder();
        while (!line.equals("End")) {
            String[] tokens = line.split("\\\\");
            String name = tokens[0];
            String[] parameters = new String[tokens.length - 1];
            System.arraycopy(tokens, 1, parameters, 0, parameters.length);

            try {
                String commandResult = this.commandHandler.executeCommand(name, parameters);
                sb.append(commandResult).append("\n");
            } catch (Exception ex) {
                sb.append(ex.getMessage()).append("\n");
            }

            line = this.reader.readLine();
        }

        this.writer.writeLine(sb.toString().trim());
    }
}
