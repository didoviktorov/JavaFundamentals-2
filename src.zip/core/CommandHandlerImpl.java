package core;

import contracts.BoatFactory;
import contracts.EngineCreator;
import models.boats.Boat;
import utility.Constants;
import contracts.BoatSimulatorController;
import contracts.CommandHandler;
import enumeration.EngineType;
import exeptions.*;

public class CommandHandlerImpl implements CommandHandler {

    private BoatSimulatorController controller;
    private BoatFactory boatFactory;
    private EngineCreator engineCreator;

    public CommandHandlerImpl(BoatSimulatorController controller, BoatFactory boatFactory, EngineCreator engineCreator) {
        this.setController(controller);
        this.boatFactory = boatFactory;
        this.engineCreator = engineCreator;
    }

    public BoatSimulatorController getController() {
        return this.controller;
    }

    @Override
    public String executeCommand(String name, String... parameters) throws DuplicateModelException, NonExistantModelException, RaceAlreadyExistsException, NoSetRaceException, InsufficientContestantsException {
        switch (name) {
            case "CreateBoatEngine":
                try {
                    return this.engineCreator.createBoatEngine(
                        parameters[0],
                        Integer.parseInt(parameters[1]),
                        Integer.parseInt(parameters[2]),
                        EngineType.valueOf(parameters[3].toUpperCase()));
                } catch (IllegalArgumentException ex) {
                    throw new IllegalArgumentException(ex.getMessage());
                }
            case "CreateRowBoat":
                return this.controller.createBoat(this.boatFactory.createRowBoat(
                        parameters[0],
                        Integer.parseInt(parameters[1]),
                        Integer.parseInt(parameters[2])));
            case "CreateSailBoat":
                return this.controller.createBoat(this.boatFactory.createSailBoat(
                        parameters[0],
                        Integer.parseInt(parameters[1]),
                        Integer.parseInt(parameters[2])));
            case "CreatePowerBoat":
                return this.controller.createBoat(this.boatFactory.createPowerBoat(
                        parameters[0],
                        Integer.parseInt(parameters[1]),
                        parameters[2],
                        parameters[3]));
            case "CreateYacht":
                return this.controller.createBoat(this.boatFactory.createYacht(
                        parameters[0],
                        Integer.parseInt(parameters[1]),
                        parameters[2],
                        Integer.parseInt(parameters[3])));
            case "OpenRace":
                return this.getController().openRace(
                        Integer.parseInt(parameters[0]),
                        Integer.parseInt(parameters[1]),
                        Integer.parseInt(parameters[2]),
                        Boolean.parseBoolean(parameters[3]));
            case "SignUpBoat":
                return this.getController().signUpBoat(parameters[0]);
            case "StartRace":
                return this.getController().startRace();
            case "GetStatistic":
                return this.getController().getStatistic();
            default:
                throw new IllegalArgumentException();
        }
    }

    private void setController(BoatSimulatorController controller) {
        this.controller = controller;
    }
}
