package comparators;

import contracts.Raceable;
import models.boats.Boat;

import java.util.Comparator;

public class BoatComparator implements Comparator<Raceable> {

    @Override
    public int compare(Raceable o1, Raceable o2) {

        return o1.compareTo(o2);
    }
}
