package contracts;

import core.Engine;
import exeptions.*;
import models.boats.Boat;

public interface BoatSimulatorController {

    String createBoat(Boat boat) throws DuplicateModelException;

    String createEngine(BoatEngine boatEngine);

    String openRace(int distance, int windSpeed, int oceanCurrentSpeed, Boolean allowsMotorboats) throws RaceAlreadyExistsException;

    String signUpBoat(String model) throws NonExistantModelException, DuplicateModelException, NoSetRaceException;

    String startRace() throws InsufficientContestantsException, NoSetRaceException;

    String getStatistic();
}
