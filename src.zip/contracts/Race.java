package contracts;

import exeptions.DuplicateModelException;

import java.util.List;

public interface Race {
    int getDistance();

    int getOceanCurrentSpeed();

    int getWindSpeed();

    boolean getAllowsMotorboats();

    void addParticipant(Raceable boat) throws DuplicateModelException;

    List<Raceable> getParticipants();
}
