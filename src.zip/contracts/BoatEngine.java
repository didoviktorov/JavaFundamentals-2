package contracts;

public interface BoatEngine extends Modelable {

    int getOutput();
}
