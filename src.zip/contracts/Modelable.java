package contracts;

public interface Modelable {

    String getModelName();
}
