package contracts;

import enumeration.EngineType;
import exeptions.DuplicateModelException;
import exeptions.NonExistantModelException;
import models.boats.Boat;

public interface BoatFactory {

    Boat createRowBoat(String model, int weight, int oars) throws DuplicateModelException;

    Boat createSailBoat(String model, int weight, int sailEfficiency) throws DuplicateModelException;

    Boat createPowerBoat(String model, int weight, String firstEngineModel, String secondEngineModel) throws NonExistantModelException, DuplicateModelException;

    Boat createYacht(String model, int weight, String engineModel, int cargoWeight) throws NonExistantModelException, DuplicateModelException;
}
