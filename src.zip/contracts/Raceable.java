package contracts;

public interface Raceable extends Modelable, Comparable<Raceable>{
    double CalculateRaceSpeed(Race race);

    double getRaceTime();

    void setRaceTime(double time);
}
