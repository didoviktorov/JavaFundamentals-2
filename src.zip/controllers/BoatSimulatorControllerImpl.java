package controllers;

import comparators.BoatComparator;
import contracts.*;
import utility.Constants;
import database.BoatSimulatorDatabase;
import exeptions.*;
import models.boats.*;
import models.race.RaceImpl;

import java.lang.reflect.Array;
import java.util.*;

public class BoatSimulatorControllerImpl implements BoatSimulatorController {

    private static final String BOAT_WITH_MODEL_IS_REGISTERED_SUCCESSFULLY = "%s boat with model %s registered successfully.";
    private static final String YACHT_WITH_MODEL_IS_REGISTERED_SUCCESSFULLY = "%s with model %s registered successfully.";

    private List<Raceable> pTimes;
    private List<Raceable> nTimes;
    private BoatSimulatorDatabase database = BoatSimulatorDatabase.getInstance();
    private Race currentRace;

    public BoatSimulatorControllerImpl() {
        this.pTimes = new LinkedList<>();
        this.nTimes = new LinkedList<>();
    }

    @Override
    public String createBoat(Boat boat) throws DuplicateModelException {
        this.database.getBoats().add(boat);
        String className = boat.getClass().getSimpleName();
        int index = className.indexOf("Boat");
        if(index != -1) {
            return className.substring(0, index) + " boat with model " + boat.getModelName() + " registered successfully.";
//            return String.format(BOAT_WITH_MODEL_IS_REGISTERED_SUCCESSFULLY,
//                className.substring(0, index), boat.getModelName());
        } else {
            return "Yacht with model " + boat.getModelName() + " registered successfully.";
//            return String.format(YACHT_WITH_MODEL_IS_REGISTERED_SUCCESSFULLY, "Yacht", boat.getModelName());
        }
    }

    @Override
    public String createEngine(BoatEngine boatEngine) {
        return null;
    }

    public String openRace(int distance, int windSpeed, int oceanCurrentSpeed, Boolean allowsMotorboats) throws RaceAlreadyExistsException {
        Race race = new RaceImpl(distance, windSpeed, oceanCurrentSpeed, allowsMotorboats);
        this.validateRaceIsEmpty();
        this.currentRace = race;
        return
                String.format(
                        "A new race with distance %s meters, wind speed %s m/s and ocean current speed %s m/s has been set.",
                        distance, windSpeed, oceanCurrentSpeed);
    }

    public String signUpBoat(String model) throws NonExistantModelException, DuplicateModelException, NoSetRaceException {
        Boat boat = this.database.getBoats().getItem(model);
        this.validateRaceIsSet();
        if (!this.currentRace.getAllowsMotorboats() && boat.isMotorBoat()) {
            throw new IllegalArgumentException(Constants.INCORRECT_BOAT_TYPE_MESSAGE);
        }

        this.currentRace.addParticipant(boat);
        Double speed = boat.CalculateRaceSpeed(this.currentRace);
        Double time = this.currentRace.getDistance() / speed;
        boat.setRaceTime(time);
        if(time > 0) {
            this.pTimes.add(boat);
        } else {
            this.nTimes.add(boat);
        }
        return "Boat with model " + model + " has signed up for the current Race.";
//        return String.format("Boat with model %s has signed up for the current Race.", model);
    }

    public String startRace() throws InsufficientContestantsException, NoSetRaceException {
        this.validateRaceIsSet();
        List<Raceable> participants = this.currentRace.getParticipants();
        if (participants.size() < 3) {
            throw new InsufficientContestantsException(Constants.INSUFFICIENT_CONTESTANTS_MESSAGE);
        }

        //this.sorter(this.pTimes, 0, this.pTimes.size() -1, new BoatComparator());
        //this.pTimes.sort(new BoatComparator());
        Collections.sort(this.pTimes);
        //Arrays.sort(this.pTimes.toArray());

        StringBuilder result = new StringBuilder();
        int position = 1;
        for (Raceable boat : this.pTimes) {
            this.appendPosition(result, position);
            position = appendRacer(participants, result, position, boat);
            if(position == 4) {
                break;
            }
        }

        if(position < 4) {
            for (Raceable boat : this.nTimes) {
                this.appendPosition(result, position);
                position = appendRacer(participants, result, position, boat);
                if(position == 4) {
                    break;
                }
            }
        }

        this.currentRace = null;
        this.pTimes.clear();
        this.nTimes.clear();
        return result.toString().trim();
    }

    private int appendRacer(List<Raceable> participants, StringBuilder result, int position, Raceable boat) {
        result.append(String.format("place: %s Model: %s Time: %s",
                boat.getClass().getSimpleName(),
                boat.getModelName(),
                isFinished(boat.getRaceTime())))
                .append(System.lineSeparator());
        participants.remove(boat);
        position++;
        return position;
    }

    @Override
    public String getStatistic() {
        return null;
    }

    private String isFinished(double key) {
        if (key <= 0 || key == Double.POSITIVE_INFINITY) {
            return "Did not finish!";
        }
        return String.format("%.2f sec", key);
    }

    private void appendPosition(StringBuilder result, int position) {
        if(position == 1) {
            result.append("First ");
        } else if(position == 2) {
            result.append("Second ");
        } else {
            result.append("Third ");
        }
    }

    private void validateRaceIsSet() throws NoSetRaceException {
        if (this.currentRace == null) {
            throw new NoSetRaceException(Constants.NO_SET_RACE_MESSAGE);
        }
    }

    private void validateRaceIsEmpty() throws RaceAlreadyExistsException {
        if (this.currentRace != null) {
            throw new RaceAlreadyExistsException(Constants.RACE_ALREADY_EXISTS_MESSAGE);
        }
    }

    private void swap(List<Raceable> list, int l, int r) {
        Raceable t = list.get(l);
        list.set(l, list.get(r));
        list.set(r, t);
    }

    private void sorter(List<Raceable> innerCollection, int left, int right, Comparator<Raceable> comparator) {
        int ll = left;
        int rr = right;

        if (rr > ll) {
            Raceable pivot = innerCollection.get((ll + rr) / 2);
            while (ll <= rr) {
                while (ll < right && comparator.compare(innerCollection.get(ll), pivot) < 0) {
                    ll += 1;
                }

                while (rr > left && comparator.compare(innerCollection.get(rr), pivot) > 0) {
                    rr -= 1;
                }

                if(ll < rr) {
                    this.swap(this.pTimes, ll, rr);
                    ll += 1;
                    rr -= 1;
                }
            }

            if(left < rr) {
                this.sorter(this.pTimes, left, rr, comparator);
            }
            if(ll < right) {
                this.sorter(this.pTimes, ll, right, comparator);
            }
        }
    }
}
