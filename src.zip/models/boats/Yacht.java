package models.boats;


import utility.Validator;
import contracts.BoatEngine;
import contracts.Race;

public class Yacht extends Boat{

    private BoatEngine boatEngine;
    private int cargoWeight;

    public Yacht(String model, int weight, boolean isMotorBoat, int cargoWeight, BoatEngine boatEngine) {
        super(model, weight, isMotorBoat);
        this.setCargoWeight(cargoWeight);
        this.setBoatEngine(boatEngine);
    }

    private void setCargoWeight(int cargoWeight) {
        Validator.validatePropertyValue(cargoWeight, "Cargo Weight");
        this.cargoWeight = cargoWeight;
    }

    private void setBoatEngine(BoatEngine boatEngine) {
        if(boatEngine == null) {
            throw new IllegalArgumentException();
        }
        this.boatEngine = boatEngine;
    }

    @Override
    public double CalculateRaceSpeed(Race race) {
        double oceanSpeed = (race.getOceanCurrentSpeed() / 2D);
        double result = this.boatEngine.getOutput() - (super.getWeight() + this.cargoWeight) + oceanSpeed;
        return result;
    }
}
