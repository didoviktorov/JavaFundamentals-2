package models.boats;

import utility.Constants;
import utility.Validator;
import contracts.Race;
import contracts.Raceable;

public abstract class Boat implements Raceable {

    private String model;
    private int weight;
    private boolean isMotorBoat;
    private double raceTime;

    protected Boat(String model, int weight, boolean isMotorBoat) {
        this.setModel(model);
        this.setWeight(weight);
        this.isMotorBoat = isMotorBoat;
        this.raceTime = 0;
    }

    @Override
    public String getModelName() {
        return this.model;
    }

    @Override
    public double getRaceTime() {
        return this.raceTime;
    }

    @Override
    public void setRaceTime(double time) {
        this.raceTime = time;
    }

    @Override
    public int compareTo(Raceable otherBoat) {
        return Double.compare(this.getRaceTime(), otherBoat.getRaceTime());
    }

    public boolean isMotorBoat() {
        return this.isMotorBoat;
    }

    public int getWeight() {
        return this.weight;
    }

    private void setModel(String model) {
        Validator.validateModelLength(model, Constants.MIN_BOAT_MODEL_LENGTH);
        this.model = model;
    }

    private void setWeight(int weight) {
        Validator.validatePropertyValue(weight, "Weight");
        this.weight = weight;
    }

    public abstract double CalculateRaceSpeed(Race race);
}
