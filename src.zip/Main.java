import contracts.*;
import core.BoatFactoryImpl;
import core.CommandHandlerImpl;
import core.Engine;
import controllers.BoatSimulatorControllerImpl;
import core.EngineCreatorImpl;
import io.InputReader;
import io.OutputWriter;

import java.io.IOException;

public class Main {
    public static void main(String[] args) throws IOException {
        BoatFactory boatFactory = new BoatFactoryImpl();
        EngineCreator engineCreator = new EngineCreatorImpl();
        BoatSimulatorController ctrl = new BoatSimulatorControllerImpl();
        CommandHandler commandHandlerImpl = new CommandHandlerImpl(ctrl, boatFactory, engineCreator);
        Writer writer = new OutputWriter();
        Reader reader = new InputReader();
        Engine engine = new Engine(commandHandlerImpl, reader, writer);

        engine.run();
    }
}
