package pr0304Barracks.core.factories;

import pr0304Barracks.contracts.Unit;
import pr0304Barracks.contracts.UnitFactory;
import pr0304Barracks.models.units.*;
import sun.reflect.generics.reflectiveObjects.NotImplementedException;

import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;

public class UnitFactoryImpl implements UnitFactory {

	private static final String UNITS_PACKAGE_NAME =
			"pr0304Barracks.models.units.";

	@Override
	public Unit createUnit(String unitType) throws NoSuchMethodException, IllegalAccessException, InvocationTargetException, InstantiationException {
		// TODO: implement for problem 3
		Constructor ctor;
		Unit unit;
		switch (unitType) {
			case "Archer":
				ctor = Archer.class.getConstructor();
				unit =  (Unit) ctor.newInstance();
				break;
			case "Swordsman":
				ctor = Swordsman.class.getConstructor();
				unit = (Unit) ctor.newInstance();
				break;
			case "Horseman":
				ctor = Horseman.class.getConstructor();
				unit = (Unit) ctor.newInstance();
				break;
			case "Gunner":
				ctor = Gunner.class.getConstructor();
				unit = (Unit) ctor.newInstance();
				break;
			default:
				ctor = Pikeman.class.getConstructor();
				unit = (Unit) ctor.newInstance();
				break;
		}

		return unit;
	}
}
