package pr0304Barracks.core;

import pr0304Barracks.contracts.CommandInterpreter;
import pr0304Barracks.contracts.Executable;
import pr0304Barracks.contracts.Repository;
import pr0304Barracks.contracts.UnitFactory;
import pr0304Barracks.core.annotations.Inject;
import pr0304Barracks.core.commands.Command;

import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;

public class CommandInterpreterImpl implements CommandInterpreter {

    private static final String COMMANDS_PACKAGE_NAME = "pr0304Barracks.core.commands.";

    private Repository repository;
    private UnitFactory unitFactory;

    public CommandInterpreterImpl(Repository repository, UnitFactory unitFactory) {
        this.repository = repository;
        this.unitFactory = unitFactory;
    }

    @Override
    @SuppressWarnings("unchecked")
    public Executable interpretCommand(String[] data, String commandName) throws
        ClassNotFoundException, NoSuchMethodException,
        IllegalAccessException, InvocationTargetException, InstantiationException {

        String className = this.getCommandClassName(commandName);
        Class execClass = Class.forName(className);

        Constructor ctor = execClass.getDeclaredConstructor(String[].class);
        Command command = (Command) ctor.newInstance((Object) data);

        Field[] fields = command.getClass().getDeclaredFields();
        for (Field field : fields) {
            String fieldName = field.getName();
            if(field.isAnnotationPresent(Inject.class) && fieldName.equals("repository")) {
                field.setAccessible(true);
                field.set(command, this.repository);
            } else if(field.isAnnotationPresent(Inject.class) && fieldName.equals("unitFactory")) {
                field.setAccessible(true);
                field.set(command, this.unitFactory);
            }
        }

        return command;
    }

    private String getCommandClassName(String commandName) {
        String result = "";
        switch (commandName) {
            case "add":
                result += COMMANDS_PACKAGE_NAME + "AddUnitCommand";
                break;
            case "report":
                result += COMMANDS_PACKAGE_NAME + "ReportCommand";
                break;
            case "fight":
                result += COMMANDS_PACKAGE_NAME + "FightCommand";
                break;
            case "retire":
                result += COMMANDS_PACKAGE_NAME + "RetireCommand";
                break;
        }

        return result;
    }
}
