package pr0304Barracks.core.commands;

import pr0304Barracks.contracts.Repository;
import pr0304Barracks.core.annotations.Inject;

import java.lang.reflect.InvocationTargetException;

public class RetireCommand extends Command {

    @Inject
    private Repository repository;

    public RetireCommand(String[] data) {
        super(data);
    }

    @Override
    public String execute() throws InvocationTargetException, NoSuchMethodException, InstantiationException, IllegalAccessException {
        String unitType = super.getData()[1];

        try {
            this.repository.removeUnit(unitType);
        } catch (IllegalArgumentException ex) {
            return "No such units in repository.";
        }

        String output = unitType + " retired!";
        return output;
    }
}
